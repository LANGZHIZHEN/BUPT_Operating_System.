#include<stdio.h>
#include<pthread.h>
#include<unistd.h>

int flag=1; //判断while循环是否继续进行的标志
int cntA=0,cntB=0; ////分别表示当前工作台上已有的的part A、part B数量
int empty=12; //表示工作台上的空位的数量，empty=12-cntA-cntB
long long id=0; //id计数
pthread_mutex_t mutexA,mutexB; //二元信号量，分别控制对countA、countB这两个变量的访问
pthread_mutex_t mutex; //二元信号量，控制对工作台的操作访问
//二元信号量，用来在控制台上没有足够空位时，分别挂起worker A和worker B还有worker C
pthread_mutex_t appendA;
pthread_mutex_t appendB;
pthread_mutex_t appendC;

void *procA(void* arg) 
{
  while(flag)
  {
	pthread_mutex_lock(&mutexA); //申请访问cntA
    pthread_mutex_lock(&mutex); //申请对控制台进行操作
    if(cntA <= 7 && empty >= 2)
	{//worker一次放两个A
      cntA += 2;
      empty -= 2;
      id++;
      printf("[%lld]Produce 2 A.",id);
      printf("Currently %d A and %d B.\n",cntA,cntB);
      //释放控制权
	  pthread_mutex_unlock(&mutex);
	  pthread_mutex_unlock(&mutexA);
      pthread_mutex_unlock(&appendC); //控制台放入了新零件，解挂C，唤醒它
    }
    else
	{
      pthread_mutex_unlock(&mutex);
	  pthread_mutex_unlock(&mutexA);
      pthread_mutex_lock(&appendA);//控制台上没有足够空位，挂起worker A
    }
  }
}

void *procB(void* arg) 
{
  while(flag)
  {
	pthread_mutex_lock(&mutexB);
    pthread_mutex_lock(&mutex);
    if(cntB <= 7 && empty >= 1)
	{//一次放一个B
      cntB++;
      empty--;
      id++;
      printf("[%lld]Produce 1 B.",id);
      printf("Currently %d A and %d B.\n",cntA,cntB);
      pthread_mutex_unlock(&mutex);
	  pthread_mutex_unlock(&mutexB);
      pthread_mutex_unlock(&appendC);
    }
    else
	{
      pthread_mutex_unlock(&mutex);
	  pthread_mutex_unlock(&mutexB);
      pthread_mutex_lock(&appendB);
    }
  }
}

void *procC(void* arg) 
{
  while(flag)
  {
	pthread_mutex_lock(&mutexA);
	pthread_mutex_lock(&mutexB);
    pthread_mutex_lock(&mutex);
    if(cntA >= 4 && cntB >= 3)
	{//合成一个C需要4A3B
      cntA -= 4;
      cntB -= 3;
      empty += 7;
      id++;
      printf("[%lld]Produce 1 C with 4 A and 3 B.",id);
      printf("Currently %d A and %d B.\n",cntA,cntB);
      pthread_mutex_unlock(&mutex);
	  pthread_mutex_unlock(&mutexA);
	  pthread_mutex_unlock(&mutexB);
      pthread_mutex_unlock(&appendA);
      pthread_mutex_unlock(&appendB);
    }
    else
	{
      pthread_mutex_unlock(&mutex);
	  pthread_mutex_unlock(&mutexA);
	  pthread_mutex_unlock(&mutexB);
      pthread_mutex_lock(&appendC); //零件不够，挂起worker C
    }
  }
}

int main()
{
  pthread_mutex_init(&mutex,NULL);
  pthread_mutex_init(&mutexA,NULL);
  pthread_mutex_init(&mutexB,NULL);
  pthread_mutex_init(&appendA,NULL);
  pthread_mutex_init(&appendB,NULL);
  pthread_mutex_init(&appendC,NULL);

  printf("starting...\n");

  pthread_t thrdA,thrdB,thrdC;
  if(pthread_create(&thrdA,NULL,procA,NULL))printf("proc A failed");
  if(pthread_create(&thrdB,NULL,procB,NULL))printf("proc B failed");
  if(pthread_create(&thrdC,NULL,procC,NULL))printf("proc C failed");
  
  sleep(1);
  printf("ending...\n");
  
  pthread_mutex_destroy(&mutex);
  pthread_mutex_destroy(&mutexA);
  pthread_mutex_destroy(&mutexB);
  pthread_mutex_destroy(&appendA);
  pthread_mutex_destroy(&appendB);
  pthread_mutex_destroy(&appendC);
}
