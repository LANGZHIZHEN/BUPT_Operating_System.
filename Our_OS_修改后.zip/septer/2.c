#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/types.h>
#include <wait.h>
#include <signal.h>

void func();

int main()
{
	int SonPro,FatPro;
	signal(17,func);
	if(SonPro=fork())
	{
		printf("Parent:Signal 17 will be send to child.\n");
		kill(SonPro,17);
		wait(0);
		printf("Child process end, Now it is father process.\n");
		printf("Father process finished.\n");
	}
	else
	{
		sleep(10);
		printf("Child:A signal from my Parent is received.\n");
		exit(0);
	}
	return 0;
}

void func()
{
	printf("It is signal 17 processing function.\n");
}
