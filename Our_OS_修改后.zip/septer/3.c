#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/types.h>
#include <unistd.h>
#include <wait.h>
#include <signal.h>

int main()
{
	if(fork())
	{
		printf("This is Father process.\n");
		sleep(1);
	}
	else
	{
		printf("This is Child process.\n");
		if(execl("/home/septer/test","./test",NULL)<0)
			perror("cannot exec test");
	}
	return 0;
}
