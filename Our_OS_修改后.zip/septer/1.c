#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/types.h>
#include <wait.h>

int main()
{
	int SonPro,FatPro,ExitSonPro;
	if(SonPro=fork())
	{
		ExitSonPro=wait(&SonPro);
		printf("Child process end, Now it is father process.\n");
		printf("Child process's id is %d, exit process's id is %d.\n",SonPro,ExitSonPro);		
	}
	else
	{
		FatPro=getpid();
		printf("Now it is child process.\n");
		printf("Child process's id is %d, father process's id is %d.\n",SonPro,FatPro);
	}
	return 0;
}
