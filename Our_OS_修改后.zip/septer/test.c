#include <stdio.h>
#include <stdlib.h>

int main()
{
	printf("This is child process, I am used by exec().\n");
	return 0;
}
