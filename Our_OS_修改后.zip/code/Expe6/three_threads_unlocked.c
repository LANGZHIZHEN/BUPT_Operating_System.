#include <sys/time.h>
#include <pthread.h>
#include<stdlib.h>
#include<stdio.h>
#include<sys/types.h>
#include<sys/sysinfo.h>
#include<unistd.h>
#define __USE_GNU
#include<sched.h>
#include<ctype.h>
#include<string.h> 
#include <sys/syscall.h> 


#define ORANGE_MAX_VALUE 1000000
#define APPLE_MAX_VALUE 100000000
#define MSECOND 1000000

struct apple
{
    unsigned long long a;
    //char c[128]; 
    unsigned long long b;
};

struct orange
{
    int a[ORANGE_MAX_VALUE];
    int b[ORANGE_MAX_VALUE];
};

struct apple acc;
struct orange acc1;
     

void* addx(void* x)
{
    unsigned long long sum=0,index=0;
    for(sum=0;sum<APPLE_MAX_VALUE;sum++)
    {
        ((struct apple *)x)->a += sum;
    }
    
    return NULL;
}

void* addy(void* y)
{
    unsigned long long sum=0,index=0;
    for(sum=0;sum<APPLE_MAX_VALUE;sum++)
    {
        ((struct apple *)y)->b += sum;
    }
    
    return NULL;
}

int main () 
{
    pthread_t ThreadA,ThreadB;
    unsigned long long sum=0,index=0;
    struct timeval time_start,time_end;
    float timeuse;
 
    gettimeofday(&time_start,NULL);
    
    pthread_create(&ThreadA,NULL,addx,&acc);
    pthread_create(&ThreadB,NULL,addy,&acc);

    for(index=0;index<ORANGE_MAX_VALUE;index++)
    {
        sum+=acc1.a[index]+acc1.b[index];
    }
    
    pthread_join(ThreadA,NULL);
    pthread_join(ThreadB,NULL);
    
    gettimeofday(&time_end,NULL);
    
    timeuse=MSECOND*(time_end.tv_sec-time_start.tv_sec)+time_end.tv_usec-time_start.tv_usec;
    timeuse/=MSECOND;

    printf("Three threads,Used Time:%f\n",timeuse); 
    
    printf("a = %llu,b = %llu,sum=%llu\n",acc.a,acc.b,sum);
  
    return 0;
}