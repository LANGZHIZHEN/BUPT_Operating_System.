# 实验2 线程的创建与管理

[toc]

<div style="page-break-after:always"></div>

## 一、实验目的

1.以 OpenEuler 等 Linux 操作系统为实验对象，加深对 Linux 进程、线程概念的理解，掌握利用 Linux 系统调用创建、管理进程的方法，掌握利用 POSIX 线程（Pthread）库创建、管理线程的方法，认识进程、线程并发执行的实质；

2.深入理解 Linux 内核提供的消息队列、共享内存、管道、软中断四种进程间通信机制，掌握利用系统调用实现进程间通信；

3.了解 Pthread 线程库提供的线程间通信机制，掌握使用 Pthread API 实现线程间通信的方法；

4.深入理解 Linux 系统提供的多种进程同步互斥机制，掌握使用信号量实现进程间的同步互斥的方法；

5.了解 Pthread 提供的线程同步互斥机制，掌握使用互斥变量和条件变量实现多线程间的同步互斥的方法；

6.通过 Linux 环境下多核多线程编程，定量分析线程自身业务逻辑、并发线程数目、线程间同步互斥关系对多线程并发/并行线程执行效率和系统吞吐量的影响，初步掌握针对复杂任务的多核多线程编程及性能分析方法。

<div style="page-break-after:always"></div>

## 二、实验设计原理

1.了解POSIX 线程标准库（Pthread 线程库）定义的线程结构和提供的线程管理API；

2.利用Pthread 线程库 API，创建管理多个线程，观察线程的结构和并发执行行为。

<div style="page-break-after:always"></div>

## 三、实验内容
### **2.1 线程库背景知识**
**2.1.1 pthread_create()**
```c++
int pthread_create(pthread_t *thread，pthread_attr_t*attr，void*(*start_routine)(void *), void *arg)
```
函数参数:
thread：该参数是指向线程标识符的指针，当线程创建成功时，用来返回创建的线程ID  
attr：该参数用于指定线程的属性，NULL表示使用默认属性  
start_routine: 该参数为一个函数指针，指向线程创建后要调用的函数，是一个以指向 void的指针作为参数和返回值的函数指针，这个被线程调用的函数也被称为线程函数。  
arg：指向传递给线程函数的参数

返回值：  
成功：0  
出错：返回错误码

**2.1.2 pthread_join()**
```c++
int pthread_join(pthread_t thread，void **thread_return)
```
函数参数:
thread：等待退出的线程ID  
thread_return：用于定义的指针，用来存储被等待线程结束时的返回值(不为NULL时)

返回值：  
成功：0  
出错：返回错误码

**2.1.3 Pthread_t pthread_self()**
```c++
Pthread_t pthread_self(void)
```
返回值：  
返回调用该函数的线程的标识ID

**2.1.4 pthread_exit()**
```c++
void pthread_exit(void *retval)
```
函数参数:
Rretval:线程结束时的返回值,可由其它函数如pthread_join0来获取。

**2.1.5 pthread_deatach()**
```c++
int pthread_detach(thread_id tid)
```
函数参数:
tid: 线程标识符

返回值：  
成功：0  
出错：返回错误码

### **2.2.1 线程的创建**

#### 使用 pthread_create()函数创建线程的实例

程序如下

```c++
/*thread_create.c*/
#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
 
/*线程函数1*/
void *mythreadl(void)
{
	int i;
	for(i=0; i<5; i++) 
    {
		printf("I am the 1st pthread, created by mybeilef321\n");
		sleep(2);
	}
}
/*线程函数2*/
void *mythread2(void)
{
	int i;
	for(i=0; i<5; i++)
    {
		printf("I am the 2st pthread, created by mybelief321\n");
		sleep(2);
	}
}
 
int main()
{
	pthread_t id1, id2;/*线程ID*/
	int res;
	/*创建一个线程，并使得该线程执行mythread1函数*/
	res=pthread_create(&id1, NULL, (void *)mythread1, NULL);
	if(res)
    {
		printf("Create pthread error!\n");
		return 1;
	}
	/*创建一个线程，并使得该线程执行mythread2函数*/
	res=pthread_create(&id2, NULL, (void *)mythread2, NULL);
	if(res) 
    {
		printf("Create pthread error!\n");
		return 1;
	}
	/*等待两个线程均推出后，main()函数再退出*/
	pthread_join(id1, NULL);
	pthread_join(id2, NULL);
 
	return 1;
}
```

程序的执行结果如下图所示

![image-20201119155808028](G:\Typora\Pic\image-20201119155808028.png)

可见两个线程以两秒的间隔交替进行



### **2.2.2 线程的退出**

#### 使用 pthread_exit()函数退出线程的举例

程序代码

```c++
/*thread_exit.c文件*/
#include<stdio.h>
#include<pthread.h>

/*进程函数*/
void *create(void *arg)
{
	printf("New thread is created...\n");
	pthread_exit((void *)6);/*这里的6也可以设置成其它数值*/
}
 
int main()
{
	pthread_t tid;
	int res;
	void *temp;
	res = pthread_create(&tid, NULL, create, NULL);
	printf("I am the main thread!\n");
	if(res) 
    {
		printf("thread is not created...\n");
		return -1;
	}
 
	res = pthread_join(tid, &temp);
	if(res) 
    {
		printf("Thread is not exit...\n");
		return -2;
	}
	printf("Thread is exit code %d \n",(int)temp);
	return 0;
}

```

程序执行结果如下图所示

![image-20201119160006990](G:\Typora\Pic\image-20201119160006990.png)  

可见创立的线程利用pthread_exit()函数结束后，主线程利用pthread_join函数获得了结束的返回值6.

### **2.2.3线程的等待**

#### 用 pthread_join()实现线程等待

程序如下：

```c++
/*thread_join.c*/
#include<pthread.h>
#include<stdio.h>

/*线程函数*/
void *thread(void *str)
{
 
	int i;
	for(i=0; i<4; ++i)
    {
		sleep(2);
		printf("This is the thread:%d\n",i);
	}
	return NULL;
}
 
int main()
{
	pthread_t pth;/*线程ID*/
	int i;
	int ret=pthread_create(&pth,NULL,thread,(void *)(i));
	pthread_join(pth,NULL);
	printf("123\n");
	for(i=0; i<3; ++i) 
    {
		sleep(1);
		printf("This is the main:%d\n",i);
	}
	return 0;
}
```

程序的执行结果如下图所示：

![image-20201119160201804](G:\Typora\Pic\image-20201119160201804.png)

可以看出，pthread_join()等到线程结束后，程序才继续执行。

### **2.2.4 获取线程的ID**

#### 使用 pthread_self()获取线程 ID

程序如下：

```c++
/*thread_id.c*/
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

void *create(void *arg)
{
    printf("New thread......\n");
    printf("This thread's id is %u \n", (unsigned int)pthread_self());
    printf("This thread process pid is %d \n", getpid());
    return NULL;
}

int main()
{
    pthread_t tid;
    int res;
    printf("Main thread is starting...\n");
    res = pthread_create(&tid, NULL, create, NULL);
    if(res)
    {
        printf("thread is not created...\n");
        return -1;
    }
    printf("The main process pid is %d \n", getpid());
    sleep(1);
    return 0;
}
```

程序的执行结果如下图所示：

![image-20201119160937958](G:\Typora\Pic\image-20201119160937958.png)

可见程序输出了线程的id以及进程的id，主线程与创立的线程的进程id是一致的。

### **2.2.5 线程的清理**

#### 线程清理函数的使用

程序代码：

```c++
/* thread_clean.c */
#include <stdio.h>
#include <pthread.h>

/*清除函数*/
void *clean(void *arg)
{
    printf("cleanup:%s \n", (char *)arg);
    return (void *)0;
}

/*线程函数1*/
void *thr_fn1(void *arg)
{
    printf("Thread1 start \n");

    pthread_cleanup_push((void *)clean, "thread1 first handler");
    pthread_cleanup_push((void *)clean, "thread1 second handler");
    printf("thread1 push complete \n");
    if(arg)
    {
        return ((void *)1);
    }
    pthread_cleanup_pop(1);
    pthread_cleanup_pop(1);
    return (void *)2;
}

void *thr_fn2(void *arg)
{
    printf("Thread2 start \n");

    pthread_cleanup_push((void *)clean, "thread2 first handler");
    pthread_cleanup_push((void *)clean, "thread2 second handler");
    printf("thread2 push complete \n");
    if(arg)
    {
        return ((void *)3);
    }
    pthread_cleanup_pop(1);
    pthread_cleanup_pop(0);
    return (void *)4;
}

int main()
{
    int res;
    pthread_t tid1, tid2;
    void *tret;

    res=pthread_create(&tid1, NULL, thr_fn1, (void *)1);
    if(res != 0)
    {
        printf("Create thread error...\n");
        return -1;
    }

    res = pthread_create(&tid2, NULL, thr_fn2, (void *)0);
    if(res != 0)
    {
        printf("Create thread error...\n");
        return -1;
    }

    res = pthread_join(tid1, &tret);
    if(res != 0)
    {
        printf("Thread_join error...\n");
        return -1;
    }
    printf("Thread1 exit code: %d\n", (int)tret);

    res = pthread_join(tid2, &tret);
    if(res != 0)
    {
        printf("Thread_join error...\n");
        return -1;
    }
    printf("Thread2 exit code: %d\n", (int)tret);

    return 0;
}
```

程序的运行结果如下图所示：

![image-20201119161116477](G:\Typora\Pic\image-20201119161116477.png)

### **2.2.6 线程之间的并行**

#### 本实验创建了 3 个进程，为了更好的描述线程之间的并行执行，让 3 个线程共用一个执行函数。每个线程都有 5 次循环(可以看成 5 个小任务)，每次循环之间会随机等待 1～10s 的时间，意义在于模拟每个任务的到达时间是随机的，并没有任何特定的规律。

程序代码：

```c++
/* thread.c */
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#define THREAD_NUMBER 3  //线程数
#define REPEAT_NUMBER 5 //每个线程中的小任务数
#define DELAY_TIME_LEVELS 10.0 //小任务之间的最大时间间隔

/* 线程函数例程 */
void *thrd_func(void *arg)
{
    int thrd_num = (int)arg;
    int delay_time = 0;
    int count = 0;

    printf("Thread %d is starting\n", thrd_num);
    for(count = 0; count < REPEAT_NUMBER; count++)
    {
        delay_time = (int)(rand()*DELAY_TIME_LEVELS/(RAND_MAX)) + 1;
        sleep(delay_time);
        printf("\tThread %d: job %d delay=%d\n", thrd_num, count, delay_time);
    }
    printf("Thread %d finished\n", thrd_num);
    pthread_exit(NULL);
}

int main(void)
{
    pthread_t thread[THREAD_NUMBER]; //存放线程id
    int no,res;
    void *thrd_ret;
    srand(time(NULL));

    for(no = 0; no < THREAD_NUMBER; no++)
    {
        res = pthread_create(&thread[no], NULL, (void *)thrd_func, (void *)(no));
        if(res != 0)
        {
            printf("Create thread %d failed\n", no);
            exit(res);
        }
    }

    printf("Creating threads success\nWaiting for threads to finish...\n");
    for(no = 0; no < THREAD_NUMBER; no++)
    {
        res = pthread_join(thread[no], &thrd_ret);
        if(!res)
        {
            printf("Thread %d joined\n", no);
        }
        else
        {
            printf("Thread %d join failed\n", no);
        }
    }

    return 0;
}
```

程序的运行结果如下图所示：

![image-20201119161228235](G:\Typora\Pic\image-20201119161228235.png)

<div style="page-break-after:always"></div>

## 四、心得体会

本次实验依托于OpenElur虚拟机，借助于WinSCP等工具。

在本次实验中，我了解了 POSIX 线程标准库（Pthread 线程库）相关知识，分析 Pthread 线程结构，掌握所提供的线程管理API，如 pthread_create, pthread_join, pthread_t pthread_self, pthread_detach, pthread_exit；查阅参考资料，利用 Pthread API，创建和管理了线程，观察了线程的结构和并发执行行为。
