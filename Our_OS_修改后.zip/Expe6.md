# 实验6 多核多线程编程及性能分析

[toc]

<div style="page-break-after:always"></div>

## 一、实验目的

1.以 OpenEuler 等 Linux 操作系统为实验对象，加深对 Linux 进程、线程概念的理解，掌握利用 Linux 系统调用创建、管理进程的方法，掌握利用 POSIX 线程（Pthread）库创建、管理线程的方法，认识进程、线程并发执行的实质；

2.深入理解 Linux 内核提供的消息队列、共享内存、管道、软中断四种进程间通信机制，掌握利用系统调用实现进程间通信；

3.了解 Pthread 线程库提供的线程间通信机制，掌握使用 Pthread API 实现线程间通信的方法；

4.深入理解 Linux 系统提供的多种进程同步互斥机制，掌握使用信号量实现进程间的同步互斥的方法；

5.了解 Pthread 提供的线程同步互斥机制，掌握使用互斥变量和条件变量实现多线程间的同步互斥的方法；

6.通过 Linux 环境下多核多线程编程，定量分析线程自身业务逻辑、并发线程数目、线程间同步互斥关系对多线程并发/并行线程执行效率和系统吞吐量的影响，初步掌握针对复杂任务的多核多线程编程及性能分析方法。

<div style="page-break-after:always"></div>

## 二、实验设计原理

1.参照参考文献“利用多核多线程进行程序优化”，在 Linux 环境下，编写多线程程序，分析以下几个因素对程序运行时间的影响：

(1)程序并行性

(2)线程数目

(3)共享资源加锁

(4)CPU亲和

(5)cache优化

2.掌握多 CPU、多核硬件环境下基本的多线程并行编程技术。

<div style="page-break-after:always"></div>

## 三、实验内容

### **6.1 观察实验平台 物理 cpu、CPU 核和逻辑cpu的数目**

#### 目的

观察实验所采用的计算机（微机、笔记本电脑）物理cpu、CPU核和逻辑cpu的数目

#### 测试环境

**CPU**:  AMD Ryzen7 5800x 8 cores 16 threads 4.85GHz   
**DRAM**:  16GB * 2 3600MHz  

通过下列命令查看CPU信息,可见物理核心数为8： 

![image-20201119170009569](G:\Typora\Pic\image-20201119170009569.png)

通过下列命令可见每个物理CPU中core的个数，由于我的CPU支持超线程，因此输出结果为2

![image-20201119170046469](G:\Typora\Pic\image-20201119170046469.png)

通过下列命令可见逻辑CPU个数，由于我的CPU是8核心16线程的，因此逻辑CPU个数为16

![image-20201119170059262](G:\Typora\Pic\image-20201119170059262.png)



### **6.2 单线程/进程串行 vs 2 线程并行 vs 3 线程加锁并行程序对比**

#### 单线程样例程序

程序代码

```c++
/*single_thread.c*/

#include <stdio.h>
#include <sys/types.h>
#include <sys/time.h>
#include <pthread.h>
#include <unistd.h>

#define ORANGE_MAX_VALUE 1000000
#define APPLE_MAX_VALUE 100000000
#define MSECOND 1000000

struct apple
{
    unsigned long long a;
    unsigned long long b;
};

struct orange
{
    int a[ORANGE_MAX_VALUE];
    int b[ORANGE_MAX_VALUE];
};

int main()
{
    struct apple test;
    struct orange test1 = { {0},{0} };

    unsigned long long sum = 0, index = 0;
    struct timeval tpstart, tpend;
    float timeuse;

    test.a = 0;
    test.b = 0;

    gettimeofday(&tpstart, NULL);

    for (sum = 0; sum < APPLE_MAX_VALUE; sum++)
    {
        test.a += sum;
        test.b += sum;
    }

    sum = 0;
    for (index = 0; index < ORANGE_MAX_VALUE; index++)
    {
        sum += test1.a[index] + test1.b[index];
    }

    gettimeofday(&tpend, NULL);

    timeuse = MSECOND * (tpend.tv_sec - tpstart.tv_sec) + tpend.tv_usec - tpstart.tv_usec;
    timeuse /= MSECOND;
    printf("main thread Used Time:%f\n", timeuse);

    printf("a = %llu,b = %llu,sum=%llu\n", test.a, test.b, sum);

    return 0;
}
```

程序执行结果如下图所示

![image-20201119170219326](G:\Typora\Pic\image-20201119170219326.png)



针对双线程程序，我们可以将互不相关的计算apple值和计算orange值的2部分代码分解为2个线程，实现线程级并行执行。

#### 双线程样例程序

程序代码

```c++
/*dual_thread.c*/
#include <sys/time.h>
#include <pthread.h>
#include<stdlib.h>
#include<stdio.h>
#include<sys/types.h>
#include<sys/sysinfo.h>
#include<unistd.h>
#define __USE_GNU
#include<sched.h>
#include<ctype.h>
#include<string.h> 
#include <sys/syscall.h> 


#define ORANGE_MAX_VALUE 1000000
#define APPLE_MAX_VALUE 100000000
#define MSECOND 1000000

struct apple
{
    unsigned long long a;
    unsigned long long b;
};

struct orange
{
    int a[ORANGE_MAX_VALUE];
    int b[ORANGE_MAX_VALUE];
};

struct apple acc;
struct orange acc1;

void* add(void* x)
{
    unsigned long long sum=0,index=0;    
    for(sum=0;sum<APPLE_MAX_VALUE;sum++)
    {
        ((struct apple *)x)->a += sum;
        ((struct apple *)x)->b += sum;    
    }
        
    return NULL;
}
    
int main () 
{
    
    pthread_t ThreadA;
    unsigned long long sum=0,index=0;
    struct timeval time_start,time_end;
    float timeuse;
    int i;
    
    acc.a=0;
    acc.b=0;

    gettimeofday(&time_start,NULL);
        
    pthread_create(&ThreadA,NULL,add,&acc);

    for(index=0;index<ORANGE_MAX_VALUE;index++)
    {
        sum += acc1.a[index]+acc1.b[index];
    }        
   
    pthread_join(ThreadA,NULL);

    gettimeofday(&time_end,NULL);
    
    timeuse=MSECOND*(time_end.tv_sec-time_start.tv_sec)+time_end.tv_usec-time_start.tv_usec;
    timeuse/=MSECOND;
    printf("dual thread Used Time:%f\n",timeuse); 
    
    printf("a = %llu,b = %llu,sum=%llu\n",acc.a,acc.b,sum);
    
    return 0;
}
```

程序的运行结果如下图所示：

![image-20201119170350272](G:\Typora\Pic\image-20201119170350272.png)



针对三线程程序，我们可以把双线程中针对apple的计算分解，一个线程用于计算apple a的值，另一个线程用于计算apple b的值  

#### 三线程加锁样例程序

程序代码：

```c++
#include <sys/time.h>
#include <pthread.h>
#include<stdlib.h>
#include<stdio.h>
#include<sys/types.h>
#include<sys/sysinfo.h>
#include<unistd.h>
#define __USE_GNU
#include<sched.h>
#include<ctype.h>
#include<string.h> 
#include <sys/syscall.h> 


#define ORANGE_MAX_VALUE 1000000
#define APPLE_MAX_VALUE 100000000
#define MSECOND 1000000

struct apple
{
    unsigned long long a;
    //char c[128]; 
    unsigned long long b;
    pthread_rwlock_t rwLock;
};

struct orange
{
    int a[ORANGE_MAX_VALUE];
    int b[ORANGE_MAX_VALUE];
};

struct apple acc;
struct orange acc1;
     

void* addx(void* x)
{
    unsigned long long sum=0,index=0;
    pthread_rwlock_wrlock(&((struct apple *)x)->rwLock);
    for(sum=0;sum<APPLE_MAX_VALUE;sum++)
    {
        ((struct apple *)x)->a += sum;
    }
    pthread_rwlock_unlock(&((struct apple *)x)->rwLock);
    
    return NULL;
}

void* addy(void* y)
{
    unsigned long long sum=0,index=0;

    pthread_rwlock_wrlock(&((struct apple *)y)->rwLock);
    for(sum=0;sum<APPLE_MAX_VALUE;sum++)
    {
        ((struct apple *)y)->b += sum;
    }
    pthread_rwlock_unlock(&((struct apple *)y)->rwLock);

    return NULL;
}

int main () 
{
    pthread_t ThreadA,ThreadB;
    unsigned long long sum=0,index=0;
    struct timeval time_start,time_end;
    float timeuse;
 
    gettimeofday(&time_start,NULL);
    
    pthread_create(&ThreadA,NULL,addx,&acc);
    pthread_create(&ThreadB,NULL,addy,&acc);

    for(index=0;index<ORANGE_MAX_VALUE;index++)
    {
        sum+=acc1.a[index]+acc1.b[index];
    }
    
    pthread_join(ThreadA,NULL);
    pthread_join(ThreadB,NULL);
    
    gettimeofday(&time_end,NULL);
    
    timeuse=MSECOND*(time_end.tv_sec-time_start.tv_sec)+time_end.tv_usec-time_start.tv_usec;
    timeuse/=MSECOND;
    printf("thread thread,Used Time:%f\n",timeuse); 
    
    printf("a = %llu,b = %llu,sum=%llu\n",acc.a,acc.b,sum);
  
    return 0;
}
```

程序的运行结果如下图所示：

![image-20201119170513609](G:\Typora\Pic\image-20201119170513609.png)

利用K-best方法测量出较为可信的时间后，我们可以画出单线程、双线程与加锁三线程时间比较的图像：  
 ![image-20201119170538352](G:\Typora\Pic\image-20201119170538352.png)
**分析**：  
从图像上我们可以看出单线程快于双线程快于三线程(加锁)，这是因为产生的额外开销大于线程的工作任务，因为线程的创建，线程间的通信以及线程的撤销都需要花费时间。而三线程加锁这线程并不是越多越好，软件线程的数量尽量能与硬件线程的数量相匹配。最好根据实际的需要，通过不断的调优，来确定线程数量的最佳值。

### **6.3 线程加锁 vs 线程不加锁对比**

#### 线程加锁的程序上面已经给出，下面给出线程不加锁的程序：

程序如下：

```c++
#include <sys/time.h>
#include <pthread.h>
#include<stdlib.h>
#include<stdio.h>
#include<sys/types.h>
#include<sys/sysinfo.h>
#include<unistd.h>
#define __USE_GNU
#include<sched.h>
#include<ctype.h>
#include<string.h> 
#include <sys/syscall.h> 


#define ORANGE_MAX_VALUE 1000000
#define APPLE_MAX_VALUE 100000000
#define MSECOND 1000000

struct apple
{
    unsigned long long a;
    //char c[128]; 
    unsigned long long b;
};

struct orange
{
    int a[ORANGE_MAX_VALUE];
    int b[ORANGE_MAX_VALUE];
};

struct apple acc;
struct orange acc1;
     

void* addx(void* x)
{
    unsigned long long sum=0,index=0;
    for(sum=0;sum<APPLE_MAX_VALUE;sum++)
    {
        ((struct apple *)x)->a += sum;
    }
    
    return NULL;
}

void* addy(void* y)
{
    unsigned long long sum=0,index=0;
    for(sum=0;sum<APPLE_MAX_VALUE;sum++)
    {
        ((struct apple *)y)->b += sum;
    }
    
    return NULL;
}

int main () 
{
    pthread_t ThreadA,ThreadB;
    unsigned long long sum=0,index=0;
    struct timeval time_start,time_end;
    float timeuse;
 
    gettimeofday(&time_start,NULL);
    
    pthread_create(&ThreadA,NULL,addx,&acc);
    pthread_create(&ThreadB,NULL,addy,&acc);

    for(index=0;index<ORANGE_MAX_VALUE;index++)
    {
        sum+=acc1.a[index]+acc1.b[index];
    }
    
    pthread_join(ThreadA,NULL);
    pthread_join(ThreadB,NULL);
    
    gettimeofday(&time_end,NULL);
    
    timeuse=MSECOND*(time_end.tv_sec-time_start.tv_sec)+time_end.tv_usec-time_start.tv_usec;
    timeuse/=MSECOND;

    printf("Three threads,Used Time:%f\n",timeuse); 
    
    printf("a = %llu,b = %llu,sum=%llu\n",acc.a,acc.b,sum);
  
    return 0;
}
```

程序的执行结果如下图所示：

![image-20201119170644825](G:\Typora\Pic\image-20201119170644825.png)

利用K-best方法得到的三线程加锁与不加锁的对比结果如下图所示：  
 ![Test2](G:\Typora\Pic\Test2.png) 
从上图可以看出，由于apple结构体中的a与b会位于缓存的同一行中，在两个进程并行执行的过程中会触发“写后写”冲突，因而导致不加锁的“并行”反而要慢于加锁的“串行”。另外在我的本机上加锁与不加锁的差距要明显高于其他同学的测试结果，我推测是我使用的新处理器(zen3架构)前端堆了很多的解码单元，针对这种只有加法的双字节指令解码速度会特别快，因而短期内会有大量的指令在执行时产生冲突，导致冲突相比其他测试机要大。

### **6.4 针对Cache的优化**

通过上一组实验，我们可以知道由于结构体中的两个元素a和b会在缓存的同一行从而触发“写后写”冲突导致不加锁比加锁速度要慢，因此我们可以采取在apple结构体的a、b元素间加入冗余变量将其地址隔开，使其从内存载入缓存中时不会在缓存的同一行。根据x86的规范，缓存一行是64B，那我们不妨在a、b中间加入一个128B大小的字符串将其隔开，如下面代码所示：

```c++
struct apple
{
    unsigned long long a;
    char c[128]; 
    unsigned long long b;
    //pthread_rwlock_t rwLock;
};
```

程序的执行结果如下图所示：

![image-20201119170806989](G:\Typora\Pic\image-20201119170806989.png)

利用K-best算法对比三线程加锁、三线程不加锁、三线程不加锁cache优化，三线程cache优化加锁，得到的对比结果如下图所示：  
 ![Test3](G:\Typora\Pic\Test3.png) 
从上图可见cache优化后由于并行化以及没有cache上的“写后写”冲突，因此效率得到大幅度提升，但是若是在cache优化的情况上再加锁等于优化无效，此时影响效率的主要是那把锁。

### **6.5 CPU亲和力对并行程序影响**

#### 1.针对两线程的方案，将计算apple的线程绑定到一个CPU上，计算orange的线程绑定到另外一个CPU上，分析对比与单线程程序、2线程

程序代码：

```c++
#define _GNU_SOURCE
#include <sched.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <assert.h>
#include <sys/time.h>
#include <pthread.h>
#include<stdlib.h>
#include<stdio.h>
#include<sys/types.h>
#include<sys/sysinfo.h>
#include<unistd.h>
#define __USE_GNU
#include<sched.h>
#include<ctype.h>
#include<string.h> 
#include <sys/syscall.h> 

pid_t gettid()
{
    return syscall(SYS_gettid);
}


#define ORANGE_MAX_VALUE 1000000
#define APPLE_MAX_VALUE 100000000
#define MSECOND 1000000

struct apple
{
    unsigned long long a;
    unsigned long long b;
};

struct orange
{
    int a[ORANGE_MAX_VALUE];
    int b[ORANGE_MAX_VALUE];
};

struct apple test;
struct orange test1;

int cpu_nums;
cpu_set_t mask;
cpu_set_t get;
     
inline int set_cpu(int i)
{
    CPU_ZERO(&mask);
    
    if(2 <= cpu_nums)
    {
        CPU_SET(i,&mask);
        
        if(-1 == sched_setaffinity(gettid(),sizeof(&mask),&mask))
        {
            return -1;
        }
    }
    return 0;
}

void* add(void* x)
{

    int i;    
    if(-1 == set_cpu(1))
    {
        return NULL;
    } 
    
   
    CPU_ZERO(&get);
    if (sched_getaffinity(0, sizeof(get), &get) == -1)
    {
        printf("warning: cound not get thread affinity, continuing...\n");
    }
    
    for (i = 0; i < 2; i++)
    {
        if (CPU_ISSET(i, &get))
        {
            printf("this thread %d is running processor : %d\n", i,i);
        }
    }

    unsigned long long sum=0,index=0;    
    for(sum=0;sum<APPLE_MAX_VALUE;sum++)
    {
        ((struct apple *)x)->a += sum;
        ((struct apple *)x)->b += sum;    
    }
        
    return NULL;
}
    
int main () 
{
    
    pthread_t ThreadA;
    unsigned long long sum=0,index=0;
    struct timeval tpstart,tpend;
    float timeuse;
    int i;
    
    test.a=0;
    test.b=0;
    
    cpu_nums = sysconf(_SC_NPROCESSORS_CONF);
    
    if(-1 == set_cpu(0))
    {
        return -1;
    } 
  
    gettimeofday(&tpstart,NULL);
        
    pthread_create(&ThreadA,NULL,add,&test);
    

    CPU_ZERO(&get);
    if (sched_getaffinity(0, sizeof(get), &get) == -1)
    {
        printf("warning: cound not get thread affinity, continuing...\n");
    }
    
    for (i = 0; i < 2; i++)
    {
        if (CPU_ISSET(i, &get))
        {
            printf("this thread %d is running processor : %d\n", i,i);
        }
    }    

    for(index=0;index<ORANGE_MAX_VALUE;index++)
    {
        sum += test1.a[index]+test1.b[index];
    }        
   
    pthread_join(ThreadA,NULL);

    gettimeofday(&tpend,NULL);
    
    timeuse=MSECOND*(tpend.tv_sec-tpstart.tv_sec)+tpend.tv_usec-tpstart.tv_usec;
    timeuse/=MSECOND;
    printf("dual threads Used Time:%f\n",timeuse); 
    
    printf("a = %llu,b = %llu,sum=%llu\n",test.a,test.b,sum);
    
    return 0;
}
```

程序的运行结果如下图所示：

![image-20201119170937655](G:\Typora\Pic\image-20201119170937655.png)

#### 2.针对三线程的亲和力优化

程序代码：

```c++
#define _GNU_SOURCE
#include <sched.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <assert.h>
#include <sys/time.h>
#include <pthread.h>
#include<sys/types.h>
#include<sys/sysinfo.h>
#define __USE_GNU
#include<sched.h>
#include<ctype.h>
#include<string.h> 
#include <sys/syscall.h> 


pid_t gettid()
{
    return syscall(SYS_gettid); 
}

#define ORANGE_MAX_VALUE 1000000
#define APPLE_MAX_VALUE 100000000
#define MSECOND 1000000

struct apple
{
    unsigned long long a;
    char c[128]; 
    unsigned long long b;
    //pthread_rwlock_t rwLock;
};

struct orange
{
    int a[ORANGE_MAX_VALUE];
    int b[ORANGE_MAX_VALUE];
};

struct apple test;
struct orange test1;

int cpu_nums;
cpu_set_t mask;
cpu_set_t get;
     
int set_cpu(int i)
{
    CPU_ZERO(&mask);
    
    if(3 <= cpu_nums)
    {
        CPU_SET(i,&mask);
        
        if(-1 == sched_setaffinity(gettid(),sizeof(&mask),&mask))
        {
            return -1;
        }
    }
    return 0;
}

void* addx(void* x)
{
    int i;
    if(-1 == set_cpu(1))
    {
        return NULL;
    }
 
    unsigned long long sum=0,index=0;

    CPU_ZERO(&get);
    if (sched_getaffinity(0, sizeof(get), &get) == -1)
    {
        printf("warning: cound not get thread affinity, continuing...\n");
    }
    
    for (i = 0; i < 3; i++)
    {
        if (CPU_ISSET(i, &get))
        {
            printf("this thread %d is running processor : %d\n", i,i);
        }
    }


   // pthread_rwlock_wrlock(&((struct apple *)x)->rwLock);
    for(sum=0;sum<APPLE_MAX_VALUE;sum++)
    {
        ((struct apple *)x)->a += sum;
    }
    //pthread_rwlock_unlock(&((struct apple *)x)->rwLock);
    
    return NULL;
}

void* addy(void* y)
{
    int i;
  
    if(-1 == set_cpu(2))
    {
        return NULL;
    }
 
    unsigned long long sum=0,index=0;

    CPU_ZERO(&get);
    if (sched_getaffinity(0, sizeof(get), &get) == -1)
    {
        printf("warning: cound not get thread affinity, continuing...\n");
    }
    
    for (i = 0; i < 3; i++)
    {
        if (CPU_ISSET(i, &get))
        {
            printf("this thread %d is running processor : %d\n", i,i);
        }
    }

    //pthread_rwlock_wrlock(&((struct apple *)y)->rwLock);
    for(sum=0;sum<APPLE_MAX_VALUE;sum++)
    {
        ((struct apple *)y)->b += sum;
    }
    //pthread_rwlock_unlock(&((struct apple *)y)->rwLock);
    
    return NULL;
}

int main () 
{
    pthread_t ThreadA,ThreadB;
    unsigned long long sum=0,index=0;
    struct timeval tpstart,tpend;
    float timeuse;
    int i;
    
    cpu_nums = sysconf(_SC_NPROCESSORS_CONF);
    
    if(-1 == set_cpu(0))
    {
        return -1;
    } 

    gettimeofday(&tpstart,NULL);
    
    pthread_create(&ThreadA,NULL,addx,&test);
    pthread_create(&ThreadB,NULL,addy,&test);

    CPU_ZERO(&get);
    if (sched_getaffinity(0, sizeof(get), &get) == -1)
    {
        printf("warning: cound not get thread affinity, continuing...\n");
    }
    
    for (i = 0; i < 3; i++)
    {
        if (CPU_ISSET(i, &get))
        {
            printf("this thread %d is running processor : %d\n", i,i);
        }
    }
    

    for(index=0;index<ORANGE_MAX_VALUE;index++)
    {
        sum+=test1.a[index]+test1.b[index];
    }
    
    pthread_join(ThreadA,NULL);
    pthread_join(ThreadB,NULL);
    
    gettimeofday(&tpend,NULL);
    
    timeuse=MSECOND*(tpend.tv_sec-tpstart.tv_sec)+tpend.tv_usec-tpstart.tv_usec;
    timeuse/=MSECOND;
    printf("Three threads,Used Time:%f\n",timeuse); 
    
    printf("a = %llu,b = %llu,sum=%llu\n",test.a,test.b,sum);
  
    return 0;
}
```

程序的运行结果如图所示：

![image-20201119171037642](G:\Typora\Pic\image-20201119171037642.png)

对比双线程、双线程硬亲和力、三线程cache优化、三线程cache优化硬亲和力的对比图如下所示：    
 ![image-20201119171102930](G:\Typora\Pic\image-20201119171102930.png)  
从上图可见由于现代cpu计算能力较强，一般不会让线程来回切换核心，另一方面现在的linux内核软亲和力也比较强，因此软亲和力和硬亲和力对比差距不大。

### **6.6  8种实现方案运行时间对比总结**

利用K-best求出均值，得到8种实现方案的对比结果图如下所示：   

![image-20201119171157481](G:\Typora\Pic\image-20201119171157481.png)

**总结**  
1.由于线程的创建会有开销，因此当开销代价相对于实际运算较大时，多线程会起到适得其反的效果，因此单线程速度快于双线程快于三线程加锁；
2.三线程时由于访问缓存时会有冲突，因此加锁反而要快于不加锁的情况； 
3.当用一定的冗余空间把结构体apple中的a、b元素隔开时，避免了缓存的写后写冲突，效率大幅度提高，由于利用了三个线程进行并行化，速度要由于单线程；  
4.由于现代cpu计算能力较强，线程不容易频繁切换核心以及linux内核的软亲和力也较强，因此实际测试中加入硬亲和力与软亲和力区别不大；  
5.我的CPU(zen3)架构由于前端解码能力大幅度提高，因而短时间内会有大量的加法指令被解码并送到后端，造成了大量的访问缓存冲突，因此三线程加锁与不加锁相较于别人的差距要更大一些。

<div style="page-break-after:always"></div>

## 四、心得体会

本次实验依托于OpenElur虚拟机，借助于WinSCP等工具。

在本次实验中，我参照参考文献“利用多核多线程进行程序优化”，在 Linux 环境下，编写多线程程序，分析了以下几个因素对程序运行时间的影响：程序并行性，线程数目，共享资源加锁，CPU亲和，cache优化；掌握了多 CPU、多核硬件环境下基本的多线程并行编程技术。

在实验进行中，我还对8种实现方案运行时间进行了对比总结。