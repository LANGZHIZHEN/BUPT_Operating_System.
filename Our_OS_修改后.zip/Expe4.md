# 实验4 线程间通信——Linux下C/C++线程间通信

[toc]



<div style="page-break-after:always"></div>

## 一、实验目的

1.以 OpenEuler 等 Linux 操作系统为实验对象，加深对 Linux 进程、线程概念的理解，掌握利用 Linux 系统调用创建、管理进程的方法，掌握利用 POSIX 线程（Pthread）库创建、管理线程的方法，认识进程、线程并发执行的实质；

2.深入理解 Linux 内核提供的消息队列、共享内存、管道、软中断四种进程间通信机制，掌握利用系统调用实现进程间通信；

3.了解 Pthread 线程库提供的线程间通信机制，掌握使用 Pthread API 实现线程间通信的方法；

4.深入理解 Linux 系统提供的多种进程同步互斥机制，掌握使用信号量实现进程间的同步互斥的方法；

5.了解 Pthread 提供的线程同步互斥机制，掌握使用互斥变量和条件变量实现多线程间的同步互斥的方法；

6.通过 Linux 环境下多核多线程编程，定量分析线程自身业务逻辑、并发线程数目、线程间同步互斥关系对多线程并发/并行线程执行效率和系统吞吐量的影响，初步掌握针对复杂任务的多核多线程编程及性能分析方法。

<div style="page-break-after:always"></div>

## 二、实验设计原理

1.Linux 中的线程概念

(1)概念

首先Linux并不存在真正的线程，Linux的线程是使用进程模拟的。当我们需要在一个进程中同时运行多个执行流时，我们并不可以开辟多个进程执行我们的操作（32位机器里每个进程认为它 **独享** 4G的内存资源），此时便引入了线程，例如当我们既需要下载内容，又需要浏览网页时，此时多线程便起了作用。线程是承担调度的基本单位，一个进程可拥有多个线程，它的执行力度比进程更加细致，线程资源共享。

(2)特点

由于同一进程的多个线程共享同一地址空间，所以代码段，数据段是共享的,如果定义一个函数（存储在代码段），各线程都可以进行调用，如果定义个全局变量（存储在数据段），在各线程中都可以访问到，除此之外，各线程还**共享**以下进程资源和环境:
①文件描述符表
②每种信号的处理方式（SIG_IGN,SIG_DFL,用户自定义）
③当前工作目录
④用户id和组id
但有些资源是线程**独享**的：
①线程id
②上下文，包括各种寄存器的值，程序计数器和栈指针
③栈空间
④errno变量
⑤信号屏蔽字
⑥调度优先级

2.线程通信机制

线程间的通信有两种情况：

(1)一个进程中的线程与另外一个进程中的线程通信，由于两个线程只能访问自己所属进程的地址空间和资源，故等同于进程间的通信。

(2)同一个进程中的两个线程进行通信。

比起进程复杂的通信机制（管道、匿名管道、消息队列、信号量、共享内存、内存映射以及socket等），线程间通信要简单的多。

因为同一进程的不同线程共享同一份全局内存区域，其中包括初始化数据段、未初始化数据段，以及堆内存段，所以线程之间可以方便、快速地共享信息。只需要将数据复制到共享（全局或堆）变量中即可。不过，要避免出现多个线程试图同时修改同一份信息。

3.线程间同步互斥模式

所在的进程中有多个线程在同时运行，而这些线程可能会同时某一段代码。如果每次运行结果和单线程运行的结果是一样的，而且其他的变量的值也和预期的是一样的，就是线程安全的。线程安全就是说多线程访问同一段代码不会产生不确定的结果。编写线程安全的代码依靠线程同步。

同步：如果变量时只读的，多个线程同时读取该变量不会有一致性问题，但是，当一个线程可以修改的变量，其他线程也可以读取或者修改的时候，我们就需要对这些线程进行同步，确保它们在访问变量的存储内容时不会访问到无效的值。

(1)互斥锁

互斥量本质上说是一把锁，在访问共享资源前对互斥量进行加锁，在访问完成后释放互斥量。对互斥量进行枷锁以后，其他视图再次对互斥量加锁的线程都会被阻塞直到当前线程释放该互斥锁。如果释放互斥量时有一个以上的线程阻塞，那么所有该锁上的阻塞线程都会变成可运行状态，第一个变成运行状态的线程可以对互斥量加锁，其他线程就会看到互斥量依然是锁着，只能再次阻塞等待它重新变成可用，这样，一次只有一个线程可以向前执行。

①常用头文件：#include <pthread.h>

②常用函数：

```c++
int pthread_mutex_init(pthread_mutex_t *mutex, const pthread_mutexattr_t *mutexattr);//互斥初始化
int pthread_mutex_destroy(pthread_mutex_t *mutex);//销毁互斥
int pthread_mutex_lock(pthread_mutex_t *mutex);//锁定互斥
int pthread_mutex_unlock(pthread_mutex_t *mutex);//解锁互斥
int pthread_mutex_trylock(pthread_mutex_t *mutex);//销毁互斥
eg.pthread_t mutex;
pthread_mutex_init(&mutex, NULL);
pthread_mutex_lock(&mutex);
...
pthread_mutex_unlock(&mutex);
pthread_mutex_detroy(&mutex);
```

③互斥锁的死锁

一个线程需要访问两个或者更多不同的共享资源，而每个资源又有不同的互斥量管理。当超过一个线程加锁同一组互斥量时，就可能发生死锁。 死锁就是指多个线程/进程因竞争资源而造成的一种僵局（相互等待），若无外力作用，这些进程都将无法向前推进。

死锁的处理策略：

a.预防死锁：破坏死锁产生的四个条件：互斥条件、不剥夺条件、请求和保持条件以及循环等待条件。

b.避免死锁：在每次进行资源分配前，应该计算此次分配资源的安全性，如果此次资源分配不会导致系统进入不安全状态，那么将资源分配给进程，否则等待。算法：银行家算法。

c.检测死锁：检测到死锁后通过资源剥夺、撤销进程、进程回退等方法解除死锁。

(2)读写锁

读写锁与互斥量类似，不过读写锁拥有更高的并行性。互斥量要么是锁住状态，要么是不加锁状态，而且一次只有一个线程可以对其加锁。读写锁有3种状态：读模式下加锁状态，写模式下加锁状态，不加锁状态。一次只有一个线程可以占有写模式的读写锁，但是多个线程可以同时占有读模式的读写锁。

当读写锁是写加锁状态时，在这个锁被解锁之前，所有视图对这个锁加锁的线程都会被阻塞。当读写锁在读加锁状态时，所有试图以读模式对它进行加锁的线程都可以得到访问权，但是任何希望以写模式对此锁进行加锁的线程都会阻塞，直到所有的线程释放它们的读锁为止。

①常用头文件：#include <pthread.h>

②常用函数

```c++
int pthread_rwlock_init(pthread_rwlock_t *rwlock, const pthread_rwlockattr_t *rwlockattr);//初始化读写锁
int pthread_rwlock_destroy(pthread_rwlock_t *rwlock);//销毁读写锁
int pthread_rwlock_rdlock(pthread_rwlock_t *rwlock);//读模式锁定读写锁
int pthread_rwlock_wrlock(pthread_rwlock_t *rwlock);//写模式锁定读写锁
int pthread_rwlock_unlock(pthread_rwlock_t *rwlock);//解锁读写锁
eg.pthread_rwlock_t q_lock;
pthread_rwlock_init(&q_lock, NULL);
pthread_rwlock_rdlock(&q_lock);
...
pthread_rwlock_unlock(&q_lock);
pthread_rwlock_detroy(&q_lock);
```

(3)条件变量

条件变量是线程可用的另一种同步机制。互斥量用于上锁，条件变量则用于等待，并且条件变量总是需要与互斥量一起使用，运行线程以无竞争的方式等待特定的条件发生。

条件变量本身是由互斥量保护的，线程在改变条件变量之前必须首先锁住互斥量。其他线程在获得互斥量之前不会察觉到这种变化，因为互斥量必须在锁定之后才能计算条件。

①常用头文件：#include <pthread.h>

②常用函数

```c++
int pthread_cond_init(pthread_cond_t *cond, const pthread_condattr_t *attr);//初始化条件变量
int pthread_cond_destroy(pthread_cond_t *cond);//销毁条件变量
int pthread_cond_wait(pthread_cond_t *cond, pthread_mutex_t *mutex);//无条件等待条件变量变为真
int pthread_cond_timewait(pthread_cond_t *cond, pthread_mutex_t *mutex, const struct timespec *tsptr);//在给定时间内，等待条件变量变为真
eg.pthread_mutex_t mutex;
pthread_cond_t cond;
...
pthread_mutex_lock(&mutex);
pthread_cond_wait(&cond, &mutex);
...
pthread_mutex_unlock(&mutex);
...
```

注意：pthread_cond_wait 执行的流程首先将这个mutex解锁, 然后等待条件变量被唤醒, 如果没有被唤醒, 该线程将一直休眠, 也就是说, 该线程将一直阻塞在这个pthread_cond_wait调用中, 而当此线程被唤醒时, 将自动将这个mutex加锁，然后再进行条件变量判断（原因是“惊群效应”，如果是多个线程都在等待这个条件，而同时只能有一个线程进行处理，此时就必须要再次条件判断，以使只有一个线程进入临界区处理），如果满足，则线程继续执行。

(4)信号量

线程的信号和进程的信号量类似，使用线程的信号量可以高效地完成基于线程的资源计数。信号量实际上是一个非负的整数计数器，用来实现对公共资源的控制。在公共资源增加的时候，信号量就增加；公共资源减少的时候，信号量就减少；只有当信号量的值大于0的时候，才能访问信号量所代表的公共资源。

①常用头文件：#include <semaphore.h>

②常用函数

```c++
sem_t sem_event;
int sem_init(sem_t *sem, int pshared, unsigned int value);//初始化一个信号量 
int sem_destroy(sem_t * sem);//销毁信号量
int sem_post(sem_t * sem);//信号量增加1
int sem_wait(sem_t * sem);//信号量减少1
int sem_getvalue(sem_t * sem, int * sval);//获取当前信号量的值
```

③互斥与同步的区别

互斥：是指某一资源同时只允许一个访问者对其进行访问，具有唯一性和排它性。但互斥无法限制访问者对资源的访问顺序，即**访问是无序**的。

同步：主要是流程上的概念，是指在互斥的基础上（大多数情况），通过其它机制实现访问者**对资源的有序访问**。**在大多数情况下，同步已经实现了互斥**，特别是所有写入资源的情况必定是互斥的。少数情况是指可以允许多个访问者同时访问资源。

④互斥锁、条件变量和信号量的区别

互斥锁：**互斥**，一个线程占用了某个资源，那么其它的线程就无法访问，直到这个线程解锁，其它线程才可以访问。

条件变量：**同步**，一个线程完成了某一个动作就通过条件变量发送信号告诉别的线程，别的线程再进行某些动作。条件变量必须和互斥锁配合使用。

信号量：**同步**，一个线程完成了某一个动作就通过信号量告诉别的线程，别的线程再进行某些动作。而且信号量有一个更加强大的功能，信号量可以用作为资源计数器，把信号量的值初始化为某个资源当前可用的数量，使用一个之后递减，归还一个之后递增。

⑤注意

a.信号量可以模拟条件变量，因为条件变量和互斥量配合使用，相当于信号量模拟条件变量和互斥量的组合。在生产者消费者线程池中，生产者生产数据后就会发送一个信号 pthread_cond_signal通知消费者线程，消费者线程通过pthread_cond_wait等待到了信号就可以继续执行。这是用条件变量和互斥锁实现生产者消费者线程的同步，用信号量一样可以实现。

b.信号量可以模拟互斥量，因为互斥量只能为加锁或解锁（0 or 1），信号量值可以为非负整数，也就是说，一个互斥量只能用于一个资源的互斥访问，它不能实现多个资源的多线程互斥问题。信号量可以实现多个同类资源的多线程互斥和同步。当信号量为单值信号量时，就完成一个资源的互斥访问。前面说了，信号量主要用做多线程多任务之间的同步，而同步能够控制线程访问的流程，当信号量为单值时，必须有线程释放，其他线程才能获得，同一个时刻只有一个线程在运行（注意，这个运行不一定是访问资源，可能是计算）。如果线程是在访问资源，就相当于实现了对这个资源的互斥访问。

c.互斥锁是为上锁而优化的；条件变量是为等待而优化的； 信号量既可用于上锁，也可用于等待，因此会有更多的开销和更高的复杂性。

d.互斥锁，条件变量都只用于同一个进程的各线程间，而信号量（有名信号量）可用于不同进程间的同步。当信号量用于进程间同步时，要求信号量建立在共享内存区。

e.互斥量必须由同一线程获取以及释放，信号量和条件变量则可以由一个线程释放，另一个线程得到。

f.信号量的递增和减少会被系统自动记住，系统内部的计数器实现信号量，不必担心丢失，而唤醒一个条件变量时，如果没有相应的线程在等待该条件变量，此次唤醒会被丢失。

(5)自旋锁

自旋锁与互斥量类似，但它不是通过休眠使进程阻塞，而是在获取锁之前一直处于忙等（自旋）阻塞状态。自旋锁可以用于以下情况：锁被持有的时间短，而且线程并不希望在重新调度上花费太多的成本。

(6)屏障

屏障是指用户可以协调多个线程并行工作的同步机制。屏障允许每个线程等待，直到所有的合作线程都到达某一点，然后从改点继续执行。

还记pthread_join函数吗？在子线程退出之前，主线程要一直等待。pthread_join函数就是一种屏障，它允许一个线程等待，直到另一个线程退出。屏障允许任意数量的线程等待，直到所有的线程完成处理工作，而线程不需要退出。所有线程达到屏障后可以接着工作。

如果我们要让主线程在所有工作线程完成之后再做某项任务，一般把屏障计数值设为工作线程数加1，主线程也作为其中一个候选线程。

4.多线程编程方式

5.参照“**【实验指导】6.2.7 Linux c/c++线程间参数传递”中的【示例2-3-3】~【示例 2-3-5】**编程实现线程间参数传递。

<div style="page-break-after:always"></div>

## 三、实验内容

### **4.1 向新建的线程传递字符串**

程序如下

```c++
#include <stdio.h>
#include <pthread.h>

void *create(char *arg)
{
    char *str;
    str = arg;
    printf("The parameter passed from main is %s\n",str);
    return (void *)0;
}

int main()
{
    int error;
    pthread_t id1;
    char *str1 = "Hello, I am in Bupt!";
    char *attr = str1;
    error = pthread_create(&id1, NULL, create, (void *)attr);

    if(error != 0)
    {
        printf("This pthread is not created!\n");
        return -1;
    }
    sleep(1);

    printf("pthread is created..\n");
    return 0;
}
```

程序的执行结果如下图所示

![image-20201119163847096](G:\Typora\Pic\image-20201119163847096.png)

不难看出，main函数中的字符串传入到新建的线程中。



### **4.2 向新建的线程传递结构体**

程序代码

```c++
#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>

struct menber
{
    int x;
    int y;
    char *s;
};

 void *create(void *arg)
{
    struct menber *temp;
    temp = (struct menber *)arg;
    printf("menber->x = %d\n",temp->x);
    printf("menber->y = %d\n",temp->y);
    printf("menber->s = %s\n",temp->s);
    return (void *)0;
}

int main()
{
    int error;
    pthread_t id1;
    struct menber *p;
    p = (struct menber *)malloc(sizeof(struct menber));
    p->x = 100;
    p->y = 100;
    p->s = "Hello world!";

    error = pthread_create(&id1,NULL,create,(void *)p);

    if(error)
    {
        printf("pthread is not created!\n");
        return -1;
    }
    sleep(1);
    printf("pthread is created!\n");

    free(p);
    p = NULL;
    return 0;
}

```

程序执行结果如下图所示

![image-20201119164134887](G:\Typora\Pic\image-20201119164134887.png)

可以看出，main函数中的一个结构体传入了新建的线程中。 线程包含了标识进程内执行环境必须的信息，集成了进程中的所有信息，对线程进行共享的，包括文本程序、程序的全局内存和堆内存、栈以及文件描述符。

### **4.3 验证新建立的线程可以共享进程中的数据**

程序如下：

```c++
#include <stdio.h>
#include <pthread.h>

static int a = 100;

void *create(void *arg)
{
    printf("New pthread...\n");
    printf("a = %d\n",a);
    return (void *)0;
}

int main(int argc, const char *argv[])
{
    int error;
    pthread_t id1;

    error = pthread_create(&id1, NULL, create, NULL);
    if(error != 0)
    {
        printf("new thread is not created!\n");
        return -1;
    }
    sleep(1);
    printf("New thread is created...\n");

    return 0;
}
```

程序的执行结果如下图所示：

![image-20201119164237068](G:\Typora\Pic\image-20201119164237068.png)

可以看出，在主线程更改全局变量a的值的时候，新建立的线程打印出改变后的值，可以看出可以访问线程所在进程中的数据信息。



<div style="page-break-after:always"></div>

## 四、心得体会

本次实验依托于OpenElur虚拟机，借助于WinSCP等工具。

在本次实验中，我了解了 Linux 中的线程概念、线程通信机制、线程间同步互斥模式，以及多线程编程方式；编程实现了线程间参数传递。
