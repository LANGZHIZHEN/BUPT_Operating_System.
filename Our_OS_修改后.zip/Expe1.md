# 实验1 进程的创建与管理

[toc]

<div style="page-break-after:always"></div>

## 一、实验目的

1.以 OpenEuler 等 Linux 操作系统为实验对象，加深对 Linux 进程、线程概念的理解，掌握利用 Linux 系统调用创建、管理进程的方法，掌握利用 POSIX 线程（Pthread）库创建、管理线程的方法，认识进程、线程并发执行的实质；

2.深入理解 Linux 内核提供的消息队列、共享内存、管道、软中断四种进程间通信机制，掌握利用系统调用实现进程间通信；

3.了解 Pthread 线程库提供的线程间通信机制，掌握使用 Pthread API 实现线程间通信的方法；

4.深入理解 Linux 系统提供的多种进程同步互斥机制，掌握使用信号量实现进程间的同步互斥的方法；

5.了解 Pthread 提供的线程同步互斥机制，掌握使用互斥变量和条件变量实现多线程间的同步互斥的方法；

6.通过 Linux 环境下多核多线程编程，定量分析线程自身业务逻辑、并发线程数目、线程间同步互斥关系对多线程并发/并行线程执行效率和系统吞吐量的影响，初步掌握针对复杂任务的多核多线程编程及性能分析方法。

<div style="page-break-after:always"></div>

## 二、实验设计原理

1.通过访问内核源文件，对源码进行结构性分析；

2.利用Linux内核提供的fork()、exec()、wait()等系统调用，创建管理多个进程，观察父子进程的结构和并发行为，掌握睡眠、撤销等进程控制方法。设计精巧实验方案，达到对包含exec在内的多个系统调用的成功调用；自己查阅exec系统调用相关资料和样例，完成实验；

3.通过查阅资料、实际应用，掌握ps、top、pstree-h、vmstat、strace、ltrace、sleep x、kill、jobs等命令的功能和使用方式；

4.int fork()：创建一个新进程

头文件：<sys/types.h><unistd.h>

返回值：在fork函数执行完毕后，如果创建新进程成功，则出现两个进程，一个是子进程，一个是父进程。在子进程中，fork函数返回0，在父进程中，fork返回新创建子进程的进程ID。我们可以通过fork返回的值来判断当前进程是子进程还是父进程。返回值等于0，说明这是从子进程返回的ID值；大于0就是从父进程返回的你所创建的子进程的子进程ID；

5.exec函数

  见三2(3)

6.(pid_t)wait(int *statloc)：来控制父进程与子进程的同步。在父进程中调用wait()函数则父进程被阻塞，进入等待队列，等待子进程结束，当子进程结束时，会产生一个终止状态字，系族会向父进程发出SIGCHLD信号。当接到信号后，父进程提取子进程的终止状态字，从wait()函数返回继续执行原程序

头文件：<sys/type.h><sys/wait.h>

返回值：wait()要与fork()配套出现,如果在使用fork()之前调用wait(),wait()的返回值则为-1,正常情况下wait()的返回值为子进程的PID；

7.int kill(pid_t pid,int sig)：用于向任何进程组或进程发送信号

头文件：<sys/types.h><signal.h>

返回值：成功执行时，返回0。失败返回-1，errno被设为以下的某个值 EINVAL：指定的信号码无效（参数 sig 不合法） EPERM；权限不够无法传送信号给指定进程 ESRCH：参数 pid 所指定的进程或进程组不存在。

<div style="page-break-after:always"></div>

## 三、实验内容

### **1.1 进程观察**

阅读Linux内核源码，分析Linux进程的组成，观察进PCB/task_struc等进程管理数据结构：

#### (1)进入/usr/src文件夹，找到内核文件，然后利用tree命令展示，因文件数量太多，只展示主要子目录

Linux tree命令用于以树状图列出目录的内容。执行tree指令，它会列出指定目录下的所有文件，包括子目录里的文件。
-C 在文件和目录清单加上色彩，便于区分各种类型。
-L level 限制目录显示层级。

![image-20201119144644712](G:\Typora\Pic\image-20201119144644712.png)

#### (2)主要子目录及其大致功能

① arch——与体系结构相关的代码。 对应于每个支持的体系结构，有一个相应的目录如x86、 arm、alpha等。每个体系结构子目录下包含几个主要的子目录：kernel、mm、lib；

② Documentation——内核方面的相关文档；

③ drivers——设备驱动代码。每类设备有相应的子目录，如char、 block、net等 fs 文件系统代码。每个支持文件系统有相应的子目录， 如ext2、proc等；

④ include——内核头文件。 对每种支持的体系结构有相应的子目录，如asm-x86、 asm-arm、asm-alpha等；

⑤ init——内核初始化代码。提供main.c，包含start kernel函数；

⑥ ipc——进程间通讯代码；

⑦ kernel——内核管理代码；

⑧ lib——与体系结构无关的内核库代码，特定体系结构的库代码保存在arch/*/lib目录下；

⑨ mm——内存管理代码；

⑩ net——内核的网络代码；

⑪ Scripts——此目录包含了内核设置时用到的脚本。

#### (3)Liuux进程的组成

关于进程，主要阅读如下文件

![image-20201119144841672](G:\Typora\Pic\image-20201119144841672.png)

①进程状态

![image-20201119144905393](G:\Typora\Pic\image-20201119144905393.png)

②我们知道，进程控制块(PCB)的是进程管理的关键。一个进程是由一个进程控制块来描述的。那么首先需要做的就是找到这部分代码。这部分代码太大，挑选部分代码进行分析说明：

![image-20201119144926030](G:\Typora\Pic\image-20201119144926030.png)

```c++
    /* 进程状态 */
    volatile long state;

    /* 指向内核栈 */
    void *stack;
    ......

     /* 指向该进程的内存区描述符 */
    struct mm_struct		*mm;
    struct mm_struct		*active_mm;
     ........

    /* 进程ID，每个进程(线程)的PID都不同 */
    pid_t pid;

    /* 线程组ID，同一个线程组拥有相同的pid，与领头线程(该组中第一个轻量级进程)pid一致，保存在tgid中，线程组领头线程的pid和tgid相同 */
    pid_t tgid;

    /* 用于连接到PID、TGID、PGRP、SESSION哈希表 */
    struct hlist_node		pid_links[PIDTYPE_MAX];
........

    /* 指向创建其的父进程，如果其父进程不存在，则指向init进程 */
    struct task_struct __rcu *real_parent;

    /* 指向当前的父进程，通常与real_parent一致 */
    struct task_struct __rcu *parent;

 

    /* 子进程链表 */
    struct list_head children;

    /* 兄弟进程链表 */
    struct list_head sibling;

    /* 线程组领头线程指针 */
    struct task_struct *group_leader;

    /* 当前目录 */
    struct fs_struct *fs;

     /* 指向文件描述符，该进程所有打开的文件会在这里面的一个指针数组里 */
    struct files_struct *files;
    ........

 　　/*信号描述符，用于跟踪共享挂起信号队列，被属于同一线程组的所有进程共享，也就是同一线程组的线程此指针指向同一个信号描述符 */
　　struct signal_struct *signal;

　　/*信号处理函数描述符 */
　　struct sighand_struct *sighand;

/* 在进程切换时保存硬件上下文(硬件上下文一共保存在2个地方: thread_struct(保存大部分CPU寄存器值，包括内核态堆栈栈顶地址和IO许可权限位)，内核栈(保存eax,ebx,ecx,edx等通用寄存器值)) */
    struct thread_struct thread;

```



### **1.2 进程创建与管理**

利用Linux内核提供的fork()、exec()、wait()等系统调用，创建管理多个进程，观察父子进程的结构和并发行为，掌握睡眠、撤销等进程控制方法；

要求：本组实验至少用到fork()、exec()、wait()、exit()、kill()、getpid五个系统调用。

exec()实验特别要求：

设计实验方案，使得父进程创建子进程后，子进程通过exec()调入自身的执行代码；

自己查阅exec系统调用相关资料和样例，完成实验。

#### (1)父进程生成子进程，父进程等待子进程wait()，子进程执行完成后自我终止exit()，并唤醒父进程，父子进程执行时打印相关信息；

程序代码

```c++
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/types.h>
#include <wait.h>

int main()
{
	int SonPro,FatPro,ExitSonPro;
	if(SonPro=fork())
	{
		ExitSonPro=wait(&SonPro);
		printf("Child process end, Now it is father process.\n");
		printf("Child process's id is %d, exit process's id is %d.\n",SonPro,ExitSonPro);		
	}
	else
	{
		FatPro=getpid();
		printf("Now it is child process.\n");
		printf("Child process's id is %d, father process's id is %d.\n",SonPro,FatPro);
	}
	return 0;
}

```

程序执行结果如下图所示

![image-20201119145307786](G:\Typora\Pic\image-20201119145307786.png)

可见父进程生成子进程，父进程等待子进程wait()，子进程执行完成后自我终止exit()，并唤醒父进程，父子进程执行时打印相关信息。

#### (2)父进程生成子进程，父进程发送信号并等待，子进程接收信号并完成某种功能；

程序代码

```c++
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/types.h>
#include <wait.h>
#include <signal.h>

void func();

int main()
{
	int SonPro,FatPro;
	signal(17,func);
	if(SonPro=fork())
	{
		printf("Parent:Signal 17 will be send to child.\n");
		kill(SonPro,17);
		wait(0);
		printf("Child process end, Now it is father process.\n");
		printf("Father process finished.\n");
	}
	else
	{
		sleep(10);
		printf("Child:A signal from my Parent is received.\n");
		exit(0);
	}
	return 0;
}

void func()
{
	printf("It is signal 17 processing function.\n");
}

```

程序执行结果如下图所示

![image-20201119145454729](G:\Typora\Pic\image-20201119145454729.png)

可见父进程生成子进程，父进程发送信号并等待，子进程接收信号并执行func函数，打印相关信息。

#### (3)父进程创建子进程后，子进程通过exec()调入自身的执行代码。

关于exec函数

exec并不是1个函数, 其实它只是一组函数的统称, 它包括下图所示6个函数:

![image-20201119145627285](G:\Typora\Pic\image-20201119145627285.png)

这6个函数的命名来源于：

![image-20201119145650407](G:\Typora\Pic\image-20201119145650407.png)

他们的使用方法的区别如下图所示：

![image-20201119145733525](G:\Typora\Pic\image-20201119145733525.png)

我们以execl函数为例进行实现。

程序代码

```c++
//3.c
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/types.h>
#include <unistd.h>
#include <wait.h>
#include <signal.h>

int main()
{
	if(fork())
	{
		printf("This is Father process.\n");
		sleep(1);
	}
	else
	{
		printf("This is Child process.\n");
		if(execl("/home/septer/test","./test",NULL)<0)
			perror("cannot exec test");
	}
	return 0;
}

//test.c
#include <stdio.h>
#include <stdlib.h>

int main()
{
	printf("This is child process, I am used by exec().\n");
	return 0;
}

```

程序运行结果如下图所示

![image-20201119145931062](G:\Typora\Pic\image-20201119145931062.png)

可见父进程创建子进程后，子进程通过exec()调入自身的执行代码。

### **1.3进程管理命令**

掌握ps、top、pstree-h、vmstat、strace、ltrace、sleep x、kill、jobs等命令的功能和使用方式；

#### (1)ps

当前运行的各进程完整信息的静态快照。通过不同的选项，可以有选择的查看进程信息。

-a ： 显示当前终端下的所有进程信息，包括其他用户的进程；

-u ：以用户为主的进程状态；

-x ：通常与 a 这个参数一起使用，显示当前用户在所有终端下的进程信息；

-e：显示系统内所有的进程信息；

-l ：使用长格式显示进程信息；

-f ：使用完整的格式显示进程信息；

执行“ps aux”命令。将以简单的列表形式显示出进程信息。

![image-20201119150126440](G:\Typora\Pic\image-20201119150126440.png)

#### (2)top

top命令将会在当前终端以全屏交互式的界面显示进程排名，及时跟踪CPU、内存等系统资源占用情况，默认情况下每三秒刷新一次，其作用类似于windows系统中的任务管理器。

![image-20201119150148701](G:\Typora\Pic\image-20201119150148701.png)

#### (3)pstree-h

pstree命令可以输出Linux系统中各个进程的树形结构，更加直观地判断出各进程之间的关系。需要注意的是，在使用 pstree 命令时，如果不指定进程的 PID 号，也不指定用户名称，则会以 init 进程为根进程，显示系统中所有程序和进程的信息；反之，若指定 PID 号或用户名，则将以 PID 或指定命令为根进程，显示 PID 或用户对应的所有程序和进程。init 进程是系统启动的第一个进程，进程的 PID 是 1，也是系统中所有进程的父进程。

-a  显示启动每个进程对应的完整指令，包括启动进程的路径、参数等。

-c  不使用精简法显示进程信息，即显示的进程中包含子进程和父进程。

-n  根据进程 PID 号来排序输出，默认是以程序名排序输出的。

-p  显示进程的 PID。

-u  显示进程对应的用户名称。

#### (4)vmstat

vmstat命令是最常见的Linux/Unix监控工具，可以展现给定时间间隔的服务器的状态值,包括服务器的CPU使用率，内存使用，虚拟内存交换情况,IO读写情况。

一般vmstat工具的使用是通过两个数字参数来完成的，第一个参数是采样的时间间隔数，单位是秒，第二个参数是采样的次数。

#### (5)strace

strace是一个可用于诊断、调试和教学的Linux用户空间跟踪器。我们用它来监控用户空间进程和内核的交互，比如系统调用、信号传递、进程状态变更等。如：strace -tt -T -v -f -e trace=file -o /data/log/strace.log -s 1024 -p 23489

-tt 在每行输出的前面，显示毫秒级别的时间

-T 显示每次系统调用所花费的时间

-v 对于某些相关调用，把完整的环境变量，文件stat结构等打出来。

-f 跟踪目标进程，以及目标进程创建的所有子进程

-e 控制要跟踪的事件和跟踪行为,比如指定要跟踪的系统调用名称

-o 把strace的输出单独写到指定的文件

-s 当系统调用的某个参数是字符串时，最多输出指定长度的内容，默认是32个字节

-p 指定要跟踪的进程pid, 要同时跟踪多个pid, 重复多次-p选项即可。

#### (6)ltrace

ltrace命令用来跟踪进程调用库函数的情况。

ltrace [option ...] [command [arg ...]]

-a 对齐具体某个列的返回值。

-c 计算时间和调用，并在程序退出时打印摘要

-C 解码低级别名称（内核级）为用户级名称。

-d 打印调试信息。

-e 改变跟踪的事件。

-f 跟踪子进程。

-h 打印帮助信息。

-i 打印指令指针，当库调用时。

-l 只打印某个库中的调用。

-L 不打印库调用。

-n, --indent=NR 对每个调用级别嵌套以NR个空格进行缩进输出。

-o, --output=file 把输出定向到文件。

-p PID 附着在值为PID的进程号上进行ltrace。

-r 打印相对时间戳。

-s STRLEN 设置打印的字符串最大长度。

-S 显示系统调用。

-t, -tt, -ttt 打印绝对时间戳。

-T 输出每个调用过程的时间开销。

-u USERNAME 使用某个用户id或组ID来运行命令。

-V, --version 打印版本信息，然后退出。

-x NAME treat the global NAME like a library subroutine.（求翻译）

#### (7)sleep x

sleep命令可以用来将目前动作延迟一段时间。

sleep [--help] [--version] number[smhd]

--help : 显示辅助讯息

--version : 显示版本编号

number : 时间长度，后面可接 s、m、h 或 d

其中 s 为秒，m 为 分钟，h 为小时，d 为日数

#### (8)kill

kill 命令用于删除执行中的程序或工作。kill 可将指定的信息送至程序。预设的信息为 SIGTERM(15)，可将指定程序终止。若仍无法终止该程序，可使用 SIGKILL(9) 信息尝试强制删除程序。程序或工作的编号可利用 ps 指令或 jobs 指令查看。

kill [-s <信息名称或编号>][程序]　或　kill [-l <信息编号>]

-l <信息编号> 　若不加<信息编号>选项，则 -l 参数会列出全部的信息名称。

-s <信息名称或编号> 　指定要送出的信息。

[程序] 　[程序]可以是程序的PID或是PGID，也可以是工作编号。

使用 kill -l 命令列出所有可用信号。

常用信号：1 (HUP)：重新加载进程。

​                    9 (KILL)：杀死一个进程。

​                   15 (TERM)：正常停止一个进程。

#### (9)jobs

jobs命令用于显示Linux中的任务列表及任务状态，包括后台运行的任务。该命令可以显示任务号及其对应的进程号。其中，任务号是以普通用户的角度进行的，而进程号则是从系统管理员的角度来看的。一个任务可以对应于一个或者多个进程号。在Linux系统中执行某些操作时候，有时需要将当前任务暂停调至后台，或有时须将后台暂停的任务重启开启并调至前台，这一序列的操作将会使用到 jobs、bg、和 fg 三个命令以及两个快捷键来完成。

jobs(选项)(参数)

参数：任务标识号——指定要显示的任务识别号。

选项：-l：显示进程号；

​           -p：仅任务对应的显示进程号；

​           -n：显示任务状态的变化；

​           -r：仅输出运行状态（running）的任务；

​           -s：仅输出停止状态（stoped）的任务。

<div style="page-break-after:always"></div>

## 四、心得体会

本次实验依托于OpenElur虚拟机，借助于WinSCP等工具。

在本次实验中，我阅读了Linux内核源码，尝试着分析了Linux进程的组成，并且观察了进PCB/task_struc等进程管理数据结构；此外，我利用Linux内核提供的fork()、exec()、wait()等系统调用，创建管理多个进程，观察父子进程的结构和并发行为，掌握了睡眠、撤销等进程控制方法；另外还掌握了ps、top、pstree-h、vmstat、strace、ltrace、sleep x、kill、jobs等命令的功能和使用方式。

在实验进行中，我还学到了利用Linux的tree命令对文件、目录进行直观、多彩的展示；学会了在虚拟机启动前进入编辑模式更改用户密码；尝试并成功启动了SELinux服务。