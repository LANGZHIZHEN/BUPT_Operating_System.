# 实验5 进程/线程同步互斥

[toc]

<div style="page-break-after:always"></div>

## 一、实验目的

1.以 OpenEuler 等 Linux 操作系统为实验对象，加深对 Linux 进程、线程概念的理解，掌握利用 Linux 系统调用创建、管理进程的方法，掌握利用 POSIX 线程（Pthread）库创建、管理线程的方法，认识进程、线程并发执行的实质；

2.深入理解 Linux 内核提供的消息队列、共享内存、管道、软中断四种进程间通信机制，掌握利用系统调用实现进程间通信；

3.了解 Pthread 线程库提供的线程间通信机制，掌握使用 Pthread API 实现线程间通信的方法；

4.深入理解 Linux 系统提供的多种进程同步互斥机制，掌握使用信号量实现进程间的同步互斥的方法；

5.了解 Pthread 提供的线程同步互斥机制，掌握使用互斥变量和条件变量实现多线程间的同步互斥的方法；

6.通过 Linux 环境下多核多线程编程，定量分析线程自身业务逻辑、并发线程数目、线程间同步互斥关系对多线程并发/并行线程执行效率和系统吞吐量的影响，初步掌握针对复杂任务的多核多线程编程及性能分析方法。

<div style="page-break-after:always"></div>

## 二、实验设计原理

1.进程：信号量操作原语/系统调用

(1) 创建一个新信号量或取得一个已有信号量：semget

```c++
#include <sys/types.h> 
#include <sys/ipc.h> 
#include <sys/sem.h>
int semget(key_t key, int nsems, int semflg);
// semget 函数成功返回一个相应信号标识符（非零），失败返回-1.
```

第一个参数 key 是整数值（唯一非零），不相关的进程可以通过它访问一个信号量，它代表程序可能要使用的某个资源，程序对所有信号量的访问都是间接的，程序先通过调用semget 函数并提供一个键，再由系统生成一个相应的信号标识符（semget 函数的返回值），只有 semget 函数才直接使用信号量键，所有其他的信号量函数使用由 semget 函数返回的信号量标识符。如果多个程序使用相同的 key 值，key 将负责协调工作。

第二个参数 num_sems 指定需要的信号量数目，它的值几乎总是 1。

第三个参数 sem_flags 是一组标志，当想要当信号量不存在时创建一个新的信号量，可以和值 IPC_CREAT 做按位或操作。设置了 IPC_CREAT 标志后，即使给出的键是一个已有信号量的键，也不会产生错误。而 IPC_CREAT | IPC_EXCL 则可以创建一个新的，唯一的信号量，如果信号量已存在，返回一个错误。

(2)信号量的初始化：semctl

```c++
int semctl (int semid, int semnum, int cmd,...);
//semid 操作句柄 semnum 指定要操作几个信号量，
//cmd 具体的操作（SETVAL 设置单个信号量初值，SETALL 设置所以信号量初值，semnum的值会被忽略）
//... 不定参数，这里是一个结构体获取信号量信息，一个联合获取信号量的值 。

union semun {
int	val;	/* Value for SETVAL */
struct semid_ds *buf;	/* Buffer for IPC_STAT, IPC_SET */
unsigned short		*array;	/* Array for GETALL, SETALL */ 
struct seminfo	*_buf;	/* Buffer for IPC_INFO(Linux-specific) */
};
```

(3)信号量wait()/signal()操作：semop

① 访问共享资源前，获取信号量-1操作

```c++
//semid 句柄，
//struct sembuf, containing the following members:
// unsigned short sem_num;	/*  信号量集合中的信号量编号，0 代表第 1 个信号量 */
//	short	sem_op;
/*若 op>0 进行V 操作信号量值加op，表示进程释放控制的资源*/
/*若 op<0 进行P 操作信号量值减o'p*/
//	short	sem_flg;
/* 设置信号量的默认操作，IPC_NOWAIT 设置信号量操作不等待*/
/*SEM_UNDO 选项会让内核记录一个与调用进程相关的 UNDO 记录，如果该进程崩溃，则根据这个进程的 UNDO 记录自动恢复相应信号量的计数值*/
struct sembuf buf; 
buf.sem_num = 0;
buf.sem_op = -1; 
buf.sem_flg = SEM_UNDO; 
semop(id, &buf, 1);
```

②访问共享资源结束，释放资源，信号量+1操作

```c++
//semid 句柄，
//struct sembuf, containing the following members:
//unsigned short sem_num;	/* semaphore number */
//	short	sem_op;	/* semaphore operation */
//	short	sem_flg;	/* operation flags */ struct sembuf buf;
buf.sem_num = 0;
buf.sem_op = 1;
buf.sem_flg = SEM_UNDO; 
semop(id, &buf, 1);
```

(4)信号量删除/释放操作：semctl

```c++
int semctl (int semid,int semnum,int cmd,...);
//释放也使用 semctl，但 cmd 的具体操作是 IPC_RMID
```



2.线程：Pthread线程同步互斥机制及API

Pthread/POSIX 提供了两种线程同步互斥机制：互斥锁和信号量，互斥锁相当于教科书中的 binary semphore，取值为 0、1；信号量则是教科书中的 counting semaphore，取值为整数。

(1)互斥锁

互斥锁控制对共享资源的原子操作，互斥锁有两种状态，即上锁和解锁。在同一个时刻 只能有一个线程掌握共享资源对应的互斥锁，拥有上锁状态的线程能够对共享资源进行操作。若其它线程希望上锁一个已经被上锁的互斥锁，则该线程就会被挂起，直到上锁的线程释放 掉互斥锁。

Pthread 提供了以下操作互斥锁机的基本函数：

互斥锁初始化：pthread_mutex_init()

互斥锁上锁：pthread_mutex_lock()

互斥锁判断上锁：pthread_mutex_trylock()

互斥锁解锁：pthread_mutex_unlock()

消除互斥锁：pthread_mutex_destroy()

有三种类型的互斥锁：快速互斥锁、递归互斥锁和检错互斥锁，三种锁的区别在于：当其它未占有互斥锁的线程希望得到互斥锁时是否需要阻塞等待。快速互斥锁是指调用线程会阻塞直至拥有互斥锁的线程解锁为止；递归互斥锁能够成功地返回，并且增加调用线程在互斥上加锁的次数而检错互斥锁则为快速互斥锁的非阻塞版本，它会立即返回并返回一个错误信息。默认属性为快速互斥锁。

![image-20201119165625639](G:\Typora\Pic\image-20201119165625639.png)

表 1 互斥锁初始化

![image-20201119165635963](G:\Typora\Pic\image-20201119165635963.png)

(2)信号量

信号量为教科书中所述的 counting semaphore，即计数信号量，即可用于进程/线程间互斥、也可以应用于进程间同步。

进程/线程通过 wait()、signal 操作（或、PV 操作），改变信号量的值，获取共享资源的访问权限，实现进程/线程同步互斥。经典的同步互斥问题有：生产者-消费者问题，读写者问题，哲学家就餐问题。

Pthread 线程库提供的信号量访问操作有：

sem_init()，创建一个信号量，并初始化它的值；

sem_wait()和 sem_trywait()，相当于 wait/P 操作，在信号量>0 时，它们能将信号量的值减 1。两者的区别在于信号量<0 时，sem_wait(0 将会阻塞进程/线程，而sem_trywait 则会立即返回。

sem_post()，相当于 signal/V 操作，它将信号量的值加 1，同时发出信号来唤醒等待的进程/线程。

sem_getvalue()，得到信号量的值。

sem_destroy()，删除信号量。

![image-20201119165654547](G:\Typora\Pic\image-20201119165654547.png)

![image-20201119165701068](G:\Typora\Pic\image-20201119165701068.png)



<div style="page-break-after:always"></div>

## 三、实验内容

【要求：参照 2019-2020 学年操作系统期末考试信号量题目，设计实现三个进程/线程 A、B、C，分别模拟题目所描述的生产产品A、B、C 的三个 worker，观察并记录进程/线程的创建和同步互斥行为。重点分析信号量设计方案是否合理、符合预期，避免设计方案导致死锁或不符合题目要求。

期末考试试题如下：

An assembly line is to produce a product C with four part As, and three part Bs. The worker of machining(加工) A and worker of machining B will produce two part As and one part B independently each time. Then the two part As or one part B will be moved to the station(工作台), which can hold at most 12 of part As and part Bs altogether. Two part As must be put onto the station simultaneously. The workers must exclusively put a part on the station or get it from the station. In addition, the worker to make C must get all part of As and Bs for one product once.

Using semaphores to coordinate the three workers who are machining part A, part B and the product C to manufacture the product without deadlock.

It is required that

(1) definition and initial value of each semaphore, and

(2) the algorithm to coordinate the production process for the three workers should be given.

】

针对 2019-2020 学年操作系统期末考试信号量题目，定义合理的锁和信号量，设计生产产品 A、B、C 的三个 worker 三个进程/线程 A、B、C 的业务流程和同步互斥机制。给出具体的设计方案，并单独提交设计方案，类似期末考试答题形式。

1.进程同步互斥

(1) 创建 3 个 Linux 进程，分别模拟生产产品 A、B、C 的三个 worker 的行为，利用 Linux内核信号量，实现三者间正确的同步互斥；

(2) 参照“【实验指导】6.5 进程间同步互斥示例”，根据上一步的设计方案，利用 semget、semctl、semop 等信号量原语，以进程方式编程实现该设计方案；观察分析程序运行结果，重点分析信号量设计方案是否合理、程序运行是否符合预期，应避免设计方案导致死锁或不符合题目要求。

2.线程同步互斥

(1)利用 Pthread API，创建 3 个 Linux 线程，分别模拟生产产品 A、B、C 的三个 worker的行为，采用Pthread 提供的信号量/管程机制，现三者间正确的同步互斥。

(2)参照“【实验指导】 6.6 线程间同步互斥示例”，根据第一步的设计方案，利用 Pthread提供的 pthread_mutex_init()、pthread_mutex_lock()、pthread_mutex_unlock()等线程同步互斥 API，以线程方式编程实现该设计方案，观察分析程序运行结果。重点分析信号量设计方案是否合理、程序运行是否符合预期，应避免设计方案导致死锁或不符合题目要求。

3.要求

基于进程和基于线程的同步互斥实现方案二选一，这里我们实现线程。

不论采用进程方式、还是线程方式，模拟A、B、C三个worker的三个进程/线程A、B、C应当多次循环反复执行，便于观察同步互斥效应。

根据设计方案，给出程序代码，程序运行结果，结果分析。

程序代码：

```c++
#include<stdio.h>
#include<pthread.h>
#include<unistd.h>

int flag=1; //判断while循环是否继续进行的标志
int cntA=0,cntB=0; ////分别表示当前工作台上已有的的part A、part B数量
int empty=12; //表示工作台上的空位的数量，empty=12-cntA-cntB
long long id=0; //id计数
pthread_mutex_t mutexA,mutexB; //二元信号量，分别控制对countA、countB这两个变量的访问
pthread_mutex_t mutex; //二元信号量，控制对工作台的操作访问
//二元信号量，用来在控制台上没有足够空位时，分别挂起worker A和worker B还有worker C
pthread_mutex_t appendA;
pthread_mutex_t appendB;
pthread_mutex_t appendC;

void *procA(void* arg) 
{
  while(flag)
  {
	pthread_mutex_lock(&mutexA); //申请访问cntA
    pthread_mutex_lock(&mutex); //申请对控制台进行操作
    if(cntA <= 7 && empty >= 2)
	{//worker一次放两个A
      cntA += 2;
      empty -= 2;
      id++;
      printf("[%lld]Produce 2 A.",id);
      printf("Currently %d A and %d B.\n",cntA,cntB);
      //释放控制权
	  pthread_mutex_unlock(&mutex);
	  pthread_mutex_unlock(&mutexA);
      pthread_mutex_unlock(&appendC); //控制台放入了新零件，解挂C，唤醒它
    }
    else
	{
      pthread_mutex_unlock(&mutex);
	  pthread_mutex_unlock(&mutexA);
      pthread_mutex_lock(&appendA);//控制台上没有足够空位，挂起worker A
    }
  }
}

void *procB(void* arg) 
{
  while(flag)
  {
	pthread_mutex_lock(&mutexB);
    pthread_mutex_lock(&mutex);
    if(cntB <= 7 && empty >= 1)
	{//一次放一个B
      cntB++;
      empty--;
      id++;
      printf("[%lld]Produce 1 B.",id);
      printf("Currently %d A and %d B.\n",cntA,cntB);
      pthread_mutex_unlock(&mutex);
	  pthread_mutex_unlock(&mutexB);
      pthread_mutex_unlock(&appendC);
    }
    else
	{
      pthread_mutex_unlock(&mutex);
	  pthread_mutex_unlock(&mutexB);
      pthread_mutex_lock(&appendB);
    }
  }
}

void *procC(void* arg) 
{
  while(flag)
  {
	pthread_mutex_lock(&mutexA);
	pthread_mutex_lock(&mutexB);
    pthread_mutex_lock(&mutex);
    if(cntA >= 4 && cntB >= 3)
	{//合成一个C需要4A3B
      cntA -= 4;
      cntB -= 3;
      empty += 7;
      id++;
      printf("[%lld]Produce 1 C with 4 A and 3 B.",id);
      printf("Currently %d A and %d B.\n",cntA,cntB);
      pthread_mutex_unlock(&mutex);
	  pthread_mutex_unlock(&mutexA);
	  pthread_mutex_unlock(&mutexB);
      pthread_mutex_unlock(&appendA);
      pthread_mutex_unlock(&appendB);
    }
    else
	{
      pthread_mutex_unlock(&mutex);
	  pthread_mutex_unlock(&mutexA);
	  pthread_mutex_unlock(&mutexB);
      pthread_mutex_lock(&appendC); //零件不够，挂起worker C
    }
  }
}

int main()
{
  pthread_mutex_init(&mutex,NULL);
  pthread_mutex_init(&mutexA,NULL);
  pthread_mutex_init(&mutexB,NULL);
  pthread_mutex_init(&appendA,NULL);
  pthread_mutex_init(&appendB,NULL);
  pthread_mutex_init(&appendC,NULL);

  printf("starting...\n");

  pthread_t thrdA,thrdB,thrdC;
  if(pthread_create(&thrdA,NULL,procA,NULL))printf("proc A failed");
  if(pthread_create(&thrdB,NULL,procB,NULL))printf("proc B failed");
  if(pthread_create(&thrdC,NULL,procC,NULL))printf("proc C failed");
  
  sleep(1); //运行1s
  printf("ending...\n");
  
  pthread_mutex_destroy(&mutex);
  pthread_mutex_destroy(&mutexA);
  pthread_mutex_destroy(&mutexB);
  pthread_mutex_destroy(&appendA);
  pthread_mutex_destroy(&appendB);
  pthread_mutex_destroy(&appendC);
}

```

程序的运行结果如下图所示：

![image-20201119164737574](G:\Typora\Pic\image-20201119164737574.png)

![image-20201119164744240](G:\Typora\Pic\image-20201119164744240.png)

<div style="page-break-after:always"></div>

## 四、心得体会

本次实验依托于OpenElur虚拟机，借助于WinSCP等工具。

在本次实验中，我了解了Linux提供的进程和线程同步互斥机制，使用了线程方式实现了同步互斥，利用信号量、互斥锁等多种方式避免了死锁，对操作系统对于死锁的规避及其完善的同步互斥机制有了更加充分的认识。