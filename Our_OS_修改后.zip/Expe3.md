# 实验3 进程间通信

[toc]

<div style="page-break-after:always"></div>

## 一、实验目的

1.以 OpenEuler 等 Linux 操作系统为实验对象，加深对 Linux 进程、线程概念的理解，掌握利用 Linux 系统调用创建、管理进程的方法，掌握利用 POSIX 线程（Pthread）库创建、管理线程的方法，认识进程、线程并发执行的实质；

2.深入理解 Linux 内核提供的消息队列、共享内存、管道、软中断四种进程间通信机制，掌握利用系统调用实现进程间通信；

3.了解 Pthread 线程库提供的线程间通信机制，掌握使用 Pthread API 实现线程间通信的方法；

4.深入理解 Linux 系统提供的多种进程同步互斥机制，掌握使用信号量实现进程间的同步互斥的方法；

5.了解 Pthread 提供的线程同步互斥机制，掌握使用互斥变量和条件变量实现多线程间的同步互斥的方法；

6.通过 Linux 环境下多核多线程编程，定量分析线程自身业务逻辑、并发线程数目、线程间同步互斥关系对多线程并发/并行线程执行效率和系统吞吐量的影响，初步掌握针对复杂任务的多核多线程编程及性能分析方法。

<div style="page-break-after:always"></div>

## 二、实验设计原理

1.消息队列：消息队列是消息的链接表，包括 Posix 消息队列 system V 消息队列。具有一定权限的进程通过向消息队列中写入组织成消息的数据、从队列中读取数据，实现相互间通信。消息队列克服了信号 signal 承载信息量少，管道 pipe 只能承载无格式字节流以及缓冲区大小受限等缺点；

详细介绍见下文。

2.共享内存：多个进程通过访问同一块内存空间，实现快速的进程间通信是最快的可用 IPC 形式。是针对其他通信机制运行效率较低而设计的。往往与其它通信机制，如信号量结合使用，来达到进程间的同步及互斥；

(1)  Linux 内核支持多种共享内存方式，如 mmap()系统调用，Posix 共享内存，以及系统 V共享内存；

(2)进程间需要共享的数据被放在一个称为 IPC 共享内存区域的地方，需要访问该共享区域的进程需要将该共享区域映射到本进程的地址空间中。系统 V 共享内存通过 shmget 获得或创建一个IPC 共享内存区域，并返回相应的标识符。内核执行 shmget 创建一个共享内存区，初始化该共享内存区对应的 shmid_kernel 结构，同时在特殊文件系统 shm 中创建并打开一个同名文件，并在内存中建立起该文件对应的 dentry 和 inode 结构。新打开的文件不属于任何一个特定进程，任何进程都可以访问该共享内存区。注意：所创建的每个共享内存区都有一个重要的控制结构 struct shmid_kernel，该结构是联系内存管理和文件系统的桥梁，定义如下：

```c++
strnuct shmid_kemel /"private to the kemel"/
{	struct kern_ipc_perm	shm_perm; struct file*	shm_file;
int id;
unsigned long shm_nattch; unsigned long shm_segsz; time_t	shm_atim;
time_t	shm_dtim;
 
time_t	shm_ctim;
pid_t	shm_cprd;
pid_t	shm_lprid;
};

```

其中，最重要的域是 shm_file，它存储了将被映射文件的地址。每个共享内存区对象都对应特殊文件系统 shm 中的一个文件，一般情况下，特殊文件系统 shm 中的文件是不能用read()、write()等方法访问的。当采取共享内存的方式将 shm 中的文件映射到进程地址空间后，可直接采用访问内存的方式访问该文件，如下图所示。

![image-20201119161706554](G:\Typora\Pic\image-20201119161706554.png)

(3)相关系统调用

① 创建共享内存

int shmget(key_t key, int size, int shmflg)

key标识共享内存的键值：0/IPC_PRIVATE。当key的取值为IPC_PRIVATE，则函数shmget将创建一块新的共享内存；如果key的取值为0，而参数中又设置了IPC_PRIVATE 这个标志，则同样会创建一块新的共享内存。

返回值。如果成功，返回共享内存表示符，如果失败，返回-1。

② 映射共享内存

int shmat(int shmid, char*shmaddr, int flag)

参数shmid：shmget函数返回的共享存储标识符，flag：决定以什么样的方式来确定映射的地址（通常为0）。

返回值。如果成功，则返回共享内存映射到进程地址空间中的地址；如果失败，则返回-1。

③ 共享内存解除映射

int shmdt(char*shmaddr)

当一个进程不再需要共享内存时，从进程的地址空间中删除共享内存。

④ 控制释放

int shmctl(int shmid, int cmd, struct shmid_ds*buf);

int shmid是共享内存的ID。int cmd是控制命令，取值如下：IPC_STAT得到共享内存的状态，IPC_SET改变共享内存的状态，IPC_RMID删除共享内存。

3.管道（Pipe）及命名管道（named pipe）：用于具有亲缘关系进程间的通信，命名管道克服了管道没有名字的限制，因此，除具有管道所具有的功能外，它还支持无亲缘关系进程间的通信；

(1)管道是进程间共享的、用于相互间通信的文件，Linux/Unix 提供了 2 种类型管道（pipe）。管道是Linux的一种通信方式，一种两个进程间进行单向通信的机制，它提供了简单的流控制机制。管道是单向的、半双工的，数据只能向一个方向流动，双方通信时需要建立两个管道。无名管道具有很多限制，即只能是在父子进程中，只能在一台机器上，同一时间只能读或者写。一个命名管道的所有实例共享同一个路径名，但是每一个实例均拥有独立的缓存与句柄。只要可以访问正确的与之关联的路径，进程间就能够彼此相互通信。

(2)无名管道（用于具有父子关系的进程间通信）

一个利用pipe()建立起来的无名文件（无路径名）、临时文件。使用该系统调用所返回的文件描述符来标识该管道文件，因此只有调用pipe()的进程及其子孙进程才能识别此文件描述符，才能利用该文件（管道）进行通信。

(3)命名管道（用于任意两个进程间通信）

一个可以在文件系统中长期存在的、具有路径名的一种特殊类型的文件，也称为FIFO 文件。它克服了无名管道使用上的局限性，允许更多的进程利用管道进行通信。其他进程可以通过文件系统知道管道的存在，并能利用路径名来访问该文件。对命名管道的访问方式与访问其他文件一样，先使用open()打开。

(4)差异：使用无名管道通信的进程之间需要一个父子关系，通信的两个进程一定是由一个共同的祖先进程启动；但无名管道没有数据交叉的问题，命名管道FIFO不同于无名管道之处在于它提供了一个路径名与之关联，以FIFO的文件形式存在于文件系统中。这样，即使与FIFO 的创建进程不存在亲缘关系的进程，只要可以访问该路径，就能够彼此通过FIFO相互通信。因此，通过FIFO不相关的进程也能交换数据。且FIFO严格遵循先进先出（first in first out），对管道及FIFO的读总是从文件开始处返回数据，对管道的写则将数据添加到管道末尾。命名管道的名字存在于文件系统中，内容存放在内存中。

(5)相关系统调用

① Pipe()

建立一无名管道的格式：pipe(filedes) 参数定义如下：

int pipe(filedes); int filedes[2];

其中，filedes[1]是写入端，filedes[0]是读出端。

② Read()

系统调用格式：read(fd, buf, nbyte)

功能：从fd所指示的文件中读出nbyte个字节的数据，并将它们送至由指针buf所指示的缓冲区中。如该文件被加锁、等待，直到锁打开为止。

参数定义如下：

int read(fd,buf,nbyte); int fd：

char *buf; unsigned nbyte;

③ Write()

系统调用格式：read((fd,buf,nbyte)

功能：把nbyte个字节的数据，从buf所指向的缓冲区写到由fd所指向的文件中。如文件加锁、暂停写入，直至开锁。

参数定义同read()。进程间通过管道用write和read来传递数据，但write和read不能同时进行，在管道中只能有4096字节数据被缓冲。

④ Sleep()

系统调用格式：sleep(second);

功能：使现行进程暂停执行由自变量规定的秒数，用于进程的同步与互斥。

⑤ Lockf()

系统调用格式：lockf(fd,mode,size);

功能：对指定文件的指定区域(由size指示)进行加锁或解锁，以实现进程的同步与互斥。其中fd是文件描述字，mode是锁定方式，=1表示加锁，=0表示解锁，size是指定文件fd的指定区域，用0表示从当前位置到文件尾。

4.信号（signal）：也称为软中断，是一种基于事件的通信机制，用于通知接受进程有某种事件发生。除了用于进程间通信外，进程还可以发送信号给进程本身；linux 除了支持 Unix 早期信号语义函数 sigal 外，还支持语义符合 Posix.1 标准的信号函数 sigaction；

(1) Linux signal/软中断机制及API

软中断信号（signal，又简称为信号）用来通知进程发生了异步事件。进程之间可以互相通过系统调用 kill 发送软中断信号。内核也可以因为内部事件而 给进程发送信号，通知进程发生了某个事件。注意，信号只是用来通知某进程发生了什么事件，并不给该进程传递任何数据。

收到信号的进程对各种信号有不同的处理方法。处理方法可以分为三类：第一种是类似中断的处理程序，对于需要处理的信号，进程可以指定处理函数，由该函数来处 理。第二种方法是，忽略某个信号，对该信号不做任何处理，就象未发生过一样。第三种方法是，对该信号的处理保留系统的默认值，这种缺省操作，对大部分的信 号的缺省操作是使得进程终止。进程通过系统调用 signal 来指定进程对某个信号的处理行为。

在进程表的 PCB 表项中有一个软中断信号域，该域中每一位对应一个信号，当有信号发送给进程时，对应位置位。由此可以看出，进程对不同的信号可以同时保留，但对于同一个信号，进程并不知道在处理之前来过多少个。

(2)相关系统调用

① Signal系统调用

用来设定某个信号的处理方法。该调用声明的格式如下：

void (*signal(int signum, void (*handler)(int)))(int); 在使用该调用的进程中加入以下头文件： #include <signal.h>

上述声明格式比较复杂，如果不清楚如何使用，也可以通过下面这种类型定义的格式来使用（POSIX 的定义）：

typedef void (*sighandler_t)(int);

sighandler_t signal(int signum, sighandler_t handler);

但这种格式在不同的系统中有不同的类型定义，所以要使用这种格式，最好还是参考一下联机手册。

其中，参数 signum 指出要设置处理方法的信号。参数 handler 是一个处理函数，或者是

SIG_IGN：忽略参数 signum 所指的信号。

SIG_DFL：恢复参数 signum 所指信号的处理方法为默认值。

传递给信号处理例程的整数参数是信号值，这样可以使得一个信号处理例程处理多个信号。系统调用 signal 返回值是指定信号 signum 前一次的处理例程或者错误时返回错误代码SIG_ERR。

② Kill系统调用

系统调用 kill 用来向进程发送一个信号。该调用声明的格式如下：

int kill(pid_t pid, int sig);

在使用该调用的进程中加入以下头文件：

\#include <sys/types.h> #include <signal.h>

该系统调用可以用来向任何进程或进程组发送任何信号。如果参数 pid 是正数，那么该调用将信号 sig 发送到进程号为 pid 的进程。如果 pid 等于 0，那么信 号 sig 将发送给当前进程所属进程组里的所有进程。如果参数 pid 等于-1，信号 sig 将发送给除了进程 1 和自身以外的所有进程。如果参数 pid 小于- 1，信号 sig 将发送给属于进程组-pid 的所有进程。如果参数 sig 为 0，将不发送信号。该调用执行成功时，返回值为 0；错误时，返回-1，并设置相应 的错误代码 errno。下面是一些可能返回的错误代码：

EINVAL：指定的信号 sig 无效。

ESRCH：参数 pid 指定的进程或进程组不存在。注意，在进程表项中存在的进程，可能是一个还没有被wait 收回，但已经终止执行的僵死进程。

EPERM： 进程没有权力将这个信号发送到指定接收信号的进程。因为，一个进程被允许将信号发送到进程 pid 时，必须拥有 root 权力，或者是发出调用的进程的 UID 或 EUID 与指定接收的进程的 UID 或保存用户 ID（savedset-user-ID）相同。如果参数 pid 小于-1，即该信号发送给一个组，则该错误 表示组中有成员进程不能接收该信号。

③ Pause系统调用

系统调用 pause 的作用是等待一个信号。该调用的声明格式如下：

int pause(void);

在使用该调用的进程中加入以下头文件：

\#include <unistd.h>

该调用使得发出调用的进程进入睡眠，直到接收到一个信号为止。该调用总是返回-1， 并设置错误代码为EINTR（接收到一个信号）。下面是一个简单的范例：

```c++
#include <unistd.h> 
#include <stdio.h> 
#include <signal.h>
void sigroutine(int unused) 
{ 
printf("Catch a signal SIGINT ");
}
int main() 
{ 
signal(SIGINT, sigroutine); 
pause();
printf("receive a signal ");
}

```

在这个例子中，程序开始执行，就象进入了死循环一样，这是因为进程正在等待信号， 当我们按下Ctrl-C 时，信号被捕捉，并且使得 pause 退出等待状态。

④ Alarm和setitimer系统调用

系统调用 alarm 的功能是设置一个定时器，当定时器计时到达时，将发出一个信号给进程。该调用的声明格式如下：

unsigned int alarm(unsigned int seconds);

在使用该调用的进程中加入以下头文件：

\#include <unistd.h>

系统调用alarm 安排内核为调用进程在指定的seconds 秒后发出一个SIGALRM 的信号。如果指定的参数seconds 为 0，则不再发送 SIGALRM 信号。后一次设定将取消前一次的设定。该调用返回值为上次定时调用到发送之间剩余的时间，或者因为没有前一次定时调用而返回 0。

注意，在使用时，alarm 只设定为发送一次信号，如果要多次发送，就要多次使用 alarm调用。

现在的系统中很多程序不再使用 alarm 调用，而是使用 setitimer 调用来设置定时器，用getitimer 来得到定时器的状态，这两个调用的声明格式如下：

int getitimer(int which, struct itimerval *value);

int setitimer(int which, const struct itimerval *value, struct itimerval *ovalue);

在使用这两个调用的进程中加入以下头文件：#include <sys/time.h>

该系统调用给进程提供了三个定时器，它们各自有其独有的计时域，当其中任何一个到达，就发送一个相应的信号给进程，并使得计时器重新开始。三个计时器由参数 which 指定，

如下所示：

TIMER_REAL：按实际时间计时，计时到达将给进程发送 SIGALRM 信号。

ITIMER_VIRTUAL：仅当进程执行时才进行计时。计时到达将发送SIGVTALRM 信号给进程。

ITIMER_PROF ： 当 进 程 执 行 时 和 系 统 为 该 进 程 执 行 动 作 时 都 计 时 。 与ITIMER_VIR-TUAL 是一对，该定时器经常用来统计进程在用户态和内核态花费的时间。计时到达将发送SIGPROF 信号给进程。

5.信号量（semaphore）：提供进程间以及同一进程内不同线程之间的同步与互斥；

6.套接口（socket）：用于不同机器之间的进程间通信。起初是由 Unix 系统的 BSD 分支开发出来的，但现在一般可以移植到其它类 Unix 系统上：Linux和 System V 的变种都支持套接字。

7.下面详细介绍消息队列系统调用。

(1)创建和访问一个消息队列，msgget

函数原型：int msgget(key_t, key, int msgflg);

与其他的IPC机制一样，程序必须提供一个键来命名某个特定的消息队列。msgflg是一个权限标志，表示消息队列的访问权限，它与文件的访问权限一样。msgflg可以与IPC_CREAT做或操作，表示当key所命名的消息队列不存在时创建一个消息队列，如果key所命名的消息队列存在时，IPC_CREAT标志会被忽略，而只返回一个标识符。

它返回一个以key命名的消息队列的标识符（非零整数），失败时返回-1.

(2)把消息添加到消息队列，即消息发送，msgsend

函数原型：int msgsend(int msgid, const void *msg_ptr, size_t msg_sz, int msgflg);

msgid是由msgget函数返回的消息队列标识符。

msg_ptr是一个指向准备发送消息的指针，但是消息的数据结构却有一定的要求，指针msg_ptr所指向的消息结构一定要是以一个长整型成员变量开始的结构体，接收函数将用这个成员来确定消息的类型。所以消息结构要定义成这样：

```c++
struct my_message{
    long int message_type;
    /* The data you wish to transfer*/
};
```

msg_sz是msg_ptr指向的消息的长度，注意是消息的长度，而不是整个结构体的长度，也就是说msg_sz是不包括长整型消息类型成员变量的长度。

msgflg用于控制当前消息队列满或队列消息到达系统范围的限制时将要发生的事情。

如果调用成功，消息数据的一分副本将被放到消息队列中，并返回0，失败时返回-1.

(3)从一个消息队列获取消息，即消息接收，msgrev

函数原型：int msgrcv(int msgid, void *msg_ptr, size_t msg_st, long int msgtype, int msgflg);

msgid, msg_ptr, msg_st的作用也函数msgsnd函数的一样。

msgtype可以实现一种简单的接收优先级。如果msgtype为0，就获取队列中的第一个消息。如果它的值大于零，将获取具有相同消息类型的第一个信息。如果它小于零，就获取类型等于或小于msgtype的绝对值的第一个消息。

msgflg用于控制当队列中没有相应类型的消息可以接收时将发生的事情。

调用成功时，该函数返回放到接收缓存区中的字节数，消息被复制到由msg_ptr指向的用户分配的缓存区中，然后删除消息队列中的对应消息。失败时返回-1.

(4)控制消息队列，msgctl

函数原型：int msgctl(int msgid, int command, struct msgid_ds *buf);

command是将要采取的动作，它可以取3个值，

IPC_STAT：把msgid_ds结构中的数据设置为消息队列的当前关联值，即用消息队列的当前关联值覆盖msgid_ds的值。

IPC_SET：如果进程有足够的权限，就把消息列队的当前关联值设置为msgid_ds结构中给出的值。

IPC_RMID：删除消息队列

buf是指向msgid_ds结构的指针，它指向消息队列模式和访问权限的结构。msgid_ds结构至少包括以下成员：

```c++
struct msgid_ds
{
    uid_t shm_perm.uid;
    uid_t shm_perm.gid;
    mode_t shm_perm.mode;
};
```

 成功时返回0，失败时返回-1。

<div style="page-break-after:always"></div>

## 三、实验内容

### **3.1 了解Linux提供的消息队列（信息传递）、共享内存、管道/命名管道、信号（signal）/软中断四种进程间通信机制的实现原理和方法**

#### (1)消息队列

消息队列是消息的链接表，包括 Posix 消息队列 system V 消息队列。具有一定权限的进程通过向消息队列中写入组织成消息的数据、从队列中读取数据，实现相互间通信。消息队列克服了信号 signal 承载信息量少，管道 pipe 只能承载无格式字节流以及缓冲区大小受限等缺点；

#### (2)共享内存

多个进程通过访问同一块内存空间，实现快速的进程间通信是最快的可用 IPC 形式。是针对其他通信机制运行效率较低而设计的。往往与其它通信机制，如信号量结合使用，来达到进程间的同步及互斥；

#### (3)管道（Pipe）及命名管道（named pipe）

用于具有亲缘关系进程间的通信，命名管道克服了管道没有名字的限制，因此，除具有管道所具有的功能外，它还支持无亲缘关系进程间的通信；

#### (4) 信号（signal）

也称为软中断，是一种基于事件的通信机制，用于通知接受进程有某种事件发生。除了用于进程间通信外，进程还可以发送信号给进程本身；linux 除了支持 Unix 早期信号语义函数 sigal 外，还支持语义符合 Posix.1 标准的信号函数 sigaction；

#### (5)信号量（semaphore）

提供进程间以及同一进程内不同线程之间的同步与互斥；

#### (6)套接口（socket）

用于不同机器之间的进程间通信。起初是由 Unix 系统的 BSD 分支开发出来的，但现在一般可以移植到其它类 Unix 系统上：Linux和 System V 的变种都支持套接字。

### **3.2 参照“【实验指导】6.3进程间通信示例”，查阅参考资料，选择上述通信方式中的一种，编程实现进程间通信，观察进程间通信过程**

为了实现不相关的进程进行通信，这里编写两个程序——msgreceive和msgsned来表示接收和发送信息。根据正常的情况，我们允许两个程序都可以创建消息，但只有接收者在接收完最后一个消息之后，它才把它删除。

接收信息的程序源文件msgreceive.c的源代码为：

```c++
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/msg.h>
 
struct msg_st
{
	long int msg_type;
	char text[BUFSIZ];
};
 
int main()
{
	int running = 1;
	int msgid = -1;
	struct msg_st data;
	long int msgtype = 0; //注意1
 
	//建立消息队列
	msgid = msgget((key_t)1234, 0666 | IPC_CREAT);
	if(msgid == -1)
	{
		fprintf(stderr, "msgget failed with error: %d\n", errno);
		exit(EXIT_FAILURE);
	}
	//从队列中获取消息，直到遇到end消息为止
	while(running)
	{
		if(msgrcv(msgid, (void*)&data, BUFSIZ, msgtype, 0) == -1)
		{
			fprintf(stderr, "msgrcv failed with errno: %d\n", errno);
			exit(EXIT_FAILURE);
		}
		printf("You wrote: %s\n",data.text);
		//遇到end结束
		if(strncmp(data.text, "end", 3) == 0)
			running = 0;
	}
	//删除消息队列
	if(msgctl(msgid, IPC_RMID, 0) == -1)
	{
		fprintf(stderr, "msgctl(IPC_RMID) failed\n");
		exit(EXIT_FAILURE);
	}
	exit(EXIT_SUCCESS);
}

```

发送信息的程序源文件msgsend.c的源代码为：

```
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/msg.h>
#include <errno.h>
 
#define MAX_TEXT 512
struct msg_st
{
	long int msg_type;
	char text[MAX_TEXT];
};
 
int main()
{
	int running = 1;
	struct msg_st data;
	char buffer[BUFSIZ];
	int msgid = -1;
 
	//建立消息队列
	msgid = msgget((key_t)1234, 0666 | IPC_CREAT);
	if(msgid == -1)
	{
		fprintf(stderr, "msgget failed with error: %d\n", errno);
		exit(EXIT_FAILURE);
	}
 
	//向消息队列中写消息，直到写入end
	while(running)
	{
		//输入数据
		printf("Enter some text: ");
		fgets(buffer, BUFSIZ, stdin);
		data.msg_type = 1;    //注意2
		strcpy(data.text, buffer);
		//向队列发送数据
		if(msgsnd(msgid, (void*)&data, MAX_TEXT, 0) == -1)
		{
			fprintf(stderr, "msgsnd failed\n");
			exit(EXIT_FAILURE);
		}
		//输入end结束输入
		if(strncmp(buffer, "end", 3) == 0)
			running = 0;
		sleep(1);
	}
	exit(EXIT_SUCCESS);
}
```

程序执行结果如下图所示

![image-20201119162754008](G:\Typora\Pic\image-20201119162754008.png)

<div style="page-break-after:always"></div>

## 四、心得体会

本次实验依托于OpenElur虚拟机，借助于WinSCP等工具。

在本次实验中，我了解了Linux提供的消息队列（信息传递）、共享内存、管道/命名管道、信号（signal）/软中断四种进程间通信机制的实现原理和方法；另外，选择了消息队列的方式，编程实现进程间通信，观察进程间通信过程。

另外，通过实验我发现，消息队列跟命名管道有不少的相同之处，通过与命名管道一样，消息队列进行通信的进程可以是不相关的进程，同时它们都是通过发送和接收的方式来传递数据的。在命名管道中，发送数据用write，接收数据用read，则在消息队列中，发送数据用msgsnd，接收数据用msgrcv。而且它们对每个数据都有一个最大长度的限制。

与命名管道相比，消息队列的优势在于：

1.消息队列也可以独立于发送和接收进程而存在，从而消除了在同步命名管道的打开和关闭时可能产生的困难。

2.同时通过发送消息还可以避免命名管道的同步和阻塞问题，不需要由进程自己来提供同步方法。

3.接收程序可以通过消息类型有选择地接收数据，而不是像命名管道中那样，只能默认地接收。